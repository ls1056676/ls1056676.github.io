<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Trustpair est une solution IT (SaaS) de Fraud Management spécialisée dans la lutte contre la fraude au virement et la sécurisation des coordonnées fournisseurs.">
    <meta name="author" content="">

    <title>Trustpair | Protégez-vous contre la fraude au virement</title>

    <!-- Google Tag Manager tracking code -->
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PFKGTK8');</script>
<!-- End Google Tag Manager -->

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Theme CSS -->
    <link href="css/agency.min.css" rel="stylesheet">

    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js" integrity="sha384-0s5Pv64cNZJieYFkXYOTId2HMA2Lfb6q2nAcx2n0RTLUnCAoTTsS0nKEO27XyKcY" crossorigin="anonymous"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js" integrity="sha384-ZoaMbDF+4LeFxg6WdScQ9nnR1QC2MIRxA1O9KWEXQwns1G8UNyIEZIQidzb0T1fo" crossorigin="anonymous"></script>
    <![endif]-->

</head>


<body id="page-legal" class="index">
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PFKGTK8"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <section id="logo"> 
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <a href="/"><img id="logo" src="img/logos/trustpair-light-background.png"></a>
                </div>
            </div>
        </div>
    </section>
    

    <!-- Header -->

    <section id="title">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h3 class="section-heading">Mentions légales</h3>
                </div>
                <div class="col-lg-10 col-lg-offset-1">
                    <div id="editeur-site" class="sub-section">
                        <h4>Editeur du site</h4>
                        <p class="text-center">
                            Trustpair</br>
                            Société par actions simplifiée au capital de 30 000 €</br>
                            55 avenue Mozart, 75016 Paris</br>
                            832 940 670 R.C.S. Paris</br>
                            contact ‘at’ trustpair ‘point’ fr
                        </p>
                    </div>
                    <div class="sub-section">
                        <h4>Hebergeur</h4>

                        <p>L’hébergement est assuré par Digital Ocean :</p>

                        <p class="text-center">
                            Digital Ocean, Inc.</br>
                            101 Avenue of the Americas, 10th Floor</br>
                            New York, NY 10013
                        </p>
                    </div>
                    <div class="sub-section">
                        <h4>Droit d'accès, de modification, de rectification et de suppression des données</h4>

                        <p>Les informations qui vous concernent sont destinées à la société Trustpair SAS. Nous nous engageons à respecter les dispositions de la loi sur l'informatique et les libertés (article 27 et article 34 de la loi n°78-17 du 6 janvier 1978 modifiée).</p>

                        <p>En conséquence, vous disposez d'un droit d'accès, de modification, de rectification et de suppression des données qui vous concernent. Pour exercer ce droit, adressez-vous par voie électronique à  contact ‘at’ trustpair ‘point’ fr ou par courrier postal à l’adresse suivante :</p>

                        <p class="text-center">Trustpair SAS</br>
                        55 avenue Mozart</br>
                        75016 Paris</p>
                    </div>
                </div>
            </div>
        </div>
    </section>


   
    <footer>
        <div class="container">
<div class="row">


<div class="col-md-4">
<ul class="list-inline quicklinks">
    <li><a href="/legal.php">Mentions légales</a></li>
    <li><a href="/jobs.php">Recrutement</a></li>
</ul>
</div>
<div class="col-md-4">
<ul class="list-inline social-buttons">
    <li><a href="https://www.linkedin.com/company/11256131/" target="_blank"><i class="fa fa-linkedin"></i></a>
    </li>
    <li><a href="https://twitter.com/trustpair" target="_blank"><i class="fa fa-twitter"></i></a>
    </li>
    <li><a href="https://www.facebook.com/trustpairfrance/" target="_blank"><i class="fa fa-facebook"></i></a>
    </li>
    
</ul>
</div>

<div class="col-md-4">
<span class="copyright">Copyright &copy; Trustpair 2017</span>
</div>

</div>
</div>
    </footer>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

</body>

</html>
