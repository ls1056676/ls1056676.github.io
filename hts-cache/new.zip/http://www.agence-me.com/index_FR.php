<!DOCTYPE html>
<html lang="fr">

	<head>

		<title>Agence Me</title>

	    <meta charset="utf-8" />

	    <meta property="og:title" content="AgenceMe" />

		<meta property="og:type" content="website" />

		<meta property="og:url" content="http://www.agence-me.com" />

		<meta property="og:image" content="http://www.agence-me.com/img/og-img.png">

	    <meta name="description" content="AgenceMe is a visual identity agency focused on product design.  We are experts in web design, mobile application (iOS and Android), impactful presentations under Keynote or Powerpoint and development (app and front-end)." />

	    <meta name="keywords" content="web design, agency, paris, san francisco, iOS, mobile, application, development, front-end, app, print, presentation, keynote, designer" />

	    <link rel="stylesheet" type="text/css" href="css/style_desktop.css"/>

	    <link rel="stylesheet" type="text/css" href="css/style_responsive.css"/>

	    <!-- THUMB -->

	    <link rel="stylesheet" type="text/css" href="thumb/css/style_desktop.css"/>

	    <link rel="stylesheet" type="text/css" href="thumb/css/style_responsive.css"/>

	    <!-- END THUMB -->

	    <!-- HEADER G -->

	    <link rel="stylesheet" type="text/css" href="header-g/css/style_desktop.css"/>

	    <link rel="stylesheet" type="text/css" href="header-g/css/style_responsive.css"/>

	    <!-- END HEADER G -->

	    <!-- FOOTER G -->

	    <link rel="stylesheet" type="text/css" href="footer-g/css/style_desktop.css"/>

	    <link rel="stylesheet" type="text/css" href="footer-g/css/style_responsive.css"/>

	    <!-- END FOOTER G -->

	    <meta name="viewport" content="width=device-width, initial-scale=1.0">

	    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>

	    <script type="text/javascript" src="js/ThreeBundle.js"></script>

	    <script type="text/javascript" src="js/AnimatedShapes.js"></script>

	    <link rel="apple-touch-icon" sizes="57x57" href="http://www.agence-me.com/img/apple-icon-57x57.png">

		<link rel="apple-touch-icon" sizes="60x60" href="http://www.agence-me.com/img/favicon/apple-icon-60x60.png">

		<link rel="apple-touch-icon" sizes="72x72" href="http://www.agence-me.com/img/favicon/apple-icon-72x72.png">

		<link rel="apple-touch-icon" sizes="76x76" href="http://www.agence-me.com/img/favicon/apple-icon-76x76.png">

		<link rel="apple-touch-icon" sizes="114x114" href="http://www.agence-me.com/img/favicon/apple-icon-114x114.png">

		<link rel="apple-touch-icon" sizes="120x120" href="http://www.agence-me.com/img/favicon/apple-icon-120x120.png">

		<link rel="apple-touch-icon" sizes="144x144" href="http://www.agence-me.com/img/favicon/apple-icon-144x144.png">

		<link rel="apple-touch-icon" sizes="152x152" href="http://www.agence-me.com/img/favicon/apple-icon-152x152.png">

		<link rel="apple-touch-icon" sizes="180x180" href="http://www.agence-me.com/img/favicon/apple-icon-180x180.png">

		<link rel="icon" type="image/png" sizes="192x192"  href="http://www.agence-me.com/img/favicon/android-icon-192x192.png">

		<link rel="icon" type="image/png" sizes="32x32" href="http://www.agence-me.com/img/favicon/favicon-32x32.png">

		<link rel="icon" type="image/png" sizes="96x96" href="http://www.agence-me.com/img/favicon/favicon-96x96.png">

		<link rel="icon" type="image/png" sizes="16x16" href="http://www.agence-me.com/img/favicon/favicon-16x16.png">

		<link rel="icon" href="http://www.agence-me.com/img/favicon/favicon-96x96.png" />

		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-43968145-1', 'auto');
		  ga('send', 'pageview');

		</script>

	</head>

	<body class="lang-fr">

		<header id="header-general-desktop">

	<div class="logo">
		<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 60 60">
			<title>Agence Me Logo</title>
			<path d="M40 53C40 36.43146 53.43146 23 70 23C86.56854 23 100 36.43146 100 53C100 69.56854 86.56854 83 70 83C53.43146 83 40 69.56854 40 53Z " fill="#3b3b48" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
			<path  d="M75.00888 46.79154C75.34639 46.354389999999995 76.06771 46 76.62 46L81.19 46C81.74228 46 81.91964 46.35687 81.58614 46.79709L72.79386 58.40291C72.46036 58.843129999999995 71.74243 59.18853 71.19032999999999 59.174369999999996L66.55966999999998 59.05564C66.00756999999999 59.04148 65.83360999999998 58.675619999999995 66.17111999999999 58.23847Z " fill="#d4d4d4" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
			<path d="M65.07157 46.79361C65.40759999999999 46.35531 66.12772 46 66.67999999999999 46L71.25 46C71.80228 46 71.97964 46.35687 71.64614 46.79709L62.853860000000005 58.40291C62.520360000000004 58.843129999999995 61.802290000000006 59.199999999999996 61.25000000000001 59.199999999999996L56.56000000000001 59.199999999999996C56.007720000000006 59.199999999999996 55.83240000000001 58.84468999999999 56.16843000000001 58.406389999999995Z " fill="#ffffff" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
			<path d="M75 47C75 46.44772 75.44772 46 76 46L80.69 46C81.24228 46 81.69 46.44772 81.69 47L81.69 55.46C81.69 56.012280000000004 81.36913 56.772240000000004 80.97332 57.1574L75.71669 62.272600000000004C75.32088 62.65776 75.00001 62.52228 75.00001 61.970000000000006Z " fill="#ffffff" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
			<path d="M66 47C66 46.44772 66.44772 46 67 46L71.69 46C72.24228 46 72.69 46.44772 72.69 47L72.69 58.2C72.69 58.752280000000006 72.24228 59.2 71.69 59.2L67 59.2C66.44772 59.2 66 58.752280000000006 66 58.2Z " fill="#f0f0f0" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
		</svg>
	</div>

	<a class="hiring f-mpl_m" href="https://angel.co/agenceme-2/jobs/314906-senior-ui-ux-designer?utm_campaign=talent&utm_content=promote_jobs_box-listing&utm_medium=al_tweet&utm_source=twitter&utm_term=agenceme-2" target="_blank">
		WE’RE HIRING
	</a>


	<div class="change-lang f-sf_m">
		<a href="index_FR.php">FR</a>
		<a href="index_EN.php">EN</a>
	</div>
	
	<a href="HireMe/" class="hire-me delay">
		<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 12.813997466514593 12.772225441594117">
			<path d="M1311.25 48C1308.35 48 1306 50.35 1306 53.25C1306 54.2 1306.25 55.09 1306.7 55.86L1306 58.45L1308.57 57.760000000000005C1309.36 58.230000000000004 1310.27 58.49 1311.25 58.49C1314.14 58.49 1316.49 56.14 1316.49 53.25C1316.49 50.35 1314.14 48 1311.25 48Z " fill-opacity="0" fill="#ffffff" stroke-dasharray="0" stroke-linejoin="miter" stroke-linecap="butt" stroke-opacity="1" stroke="#ff5f26" stroke-miterlimit="50" stroke-width="1.5" transform="matrix(1,0,0,1,-1305.0930012667427,-47.11388727920294)"></path>
			<span class="f-sf_m">HIRE ME</span>
		</svg>
	</a>

	<div class="menu">

		<div class="round"></div>

		<div class="bar-1"></div>

		<div class="bar-cross-1"></div>
		<div class="bar-cross-2"></div>

		<div class="bar-2"></div>
		
	</div>
	
</header>

<div id="header-general-desktop-content">
	
	<div class="title f-mpl_1">
		<h4>THE FRENCH AGENCY</h4>
	</div>

	<div class="container-link">

		<div class="li-link">

			<div class="f-mpl_m">.01</div>
			<a href="http://agence-me.com/Website/" class="f-mpl_3 delay">HOME</a>
			
		</div><div class="li-link">

			<div class="f-mpl_m">.02</div>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_3 delay">WORK</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">ACCROSPORT</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">HEJMO</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">SPONSEASY</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">PETIT BUS</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">THOUGHSPOT</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">STUDYQUIZZ</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">XOLA</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">FLOOZ</a>
			<a href="http://agence-me.com/Website/Work" class="f-mpl_m delay">SPOOTNIK</a>
			
		</div><div class="li-link">

			<div class="f-mpl_m">.03</div>
			<a href="http://agence-me.com/Website/OurVision" class="f-mpl_3 delay">VISION</a>
			
		</div><div class="li-link">

			<div class="f-mpl_m">.04</div>
			<a href="#" class="f-mpl_3 delay">THE AGENCY</a>
			<a href="#" class="f-mpl_m delay">ABOUT US</a>
			<a href="#" class="f-mpl_m delay">OUR HOME</a>
			<a href="#" class="f-mpl_m delay">OUR INSPIRATION</a>
			<a href="#" class="f-mpl_m delay">WHAT WE LISTENING NOW ?</a>
			<a href="#" class="f-mpl_m delay">CONTACT US</a>
			
		</div><div class="li-link">

			<div class="f-mpl_m" style="color: #7cbdb5;">.05</div>
			<a href="http://www.market-me.fr" class="f-mpl_3 delay" style="color: #7cbdb5;">MARKET ME</a>
			<span class="f-hn_r">The MarketPlace for Premium<br> Design Resources</span>
			
		</div>

		
	</div>
	
</div>

<script>

	$(window).scroll(function () {

	    if ($(window).scrollTop() > 100) {
	       $('#header-general-desktop').addClass('scroll');
	       $('.shape').addClass('min');

	    } else {
	       $('#header-general-desktop').removeClass('scroll');
	       $('.shape').removeClass('min');
	    }

	})

	$('#header-general-desktop .menu').click(function() {

		$(this).toggleClass('open');

		if 	($('#header-general-desktop-content').hasClass('open')) {

			$('#header-general-desktop-content').removeClass('open');

			setTimeout(function() {

				$('#header-general-desktop-content').hide();

			}, 500);

		}else{

			$('#header-general-desktop-content').show();

			setTimeout(function() {

				$('#header-general-desktop-content').addClass('open');

			}, 50);
		}
	})


	

	$('#header-general-desktop-content a').click(function() {
		$('#header-general-desktop .menu').removeClass('open');
		$('#header-general-desktop-content').removeClass('open');
	})
</script>
		<div id="container-general" class="active-nav-home">

			<ul id="nav-general">

				<div class="nav-general_select"></div>		

				<li>
					<div></div>
				</li>
				<li>
					<div></div>
				</li>
				<li>
					<div></div>
				</li>
				<li>
					<div></div>
				</li>
				<li>
					<div></div>
				</li>
				<li>
					<div></div>
				</li>
				<li>
					<div></div>
				</li>
				
			</ul>

			<div id="shape-icosahedron" class="shape"></div>

			<section id="section-home">

				<div class="section-home_content">

					<div class="section-home_title f-mpl_1">
						<h1>ME</h1>
					</div>

					<div class="section-home_subtitle f-sf_m">
						<h3>THE FRENCH AGENCY</h3>
						<h4>Design & Développement</h4>
					</div>

				</div>
				
				<!--
				<div class="section-home_scroll">

					<div class="section-home_scroll_content active">

						<div class="section-home_scroll_content_point"></div>
						<div class="section-home_scroll_content_point"></div>
						<div class="section-home_scroll_content_point"></div>
						
					</div>
					
				</div> -->

			</section>
			
			
			<section id="section-work">
				
				<div class="section-work_title f-mpl_1">
					<h2>OUR WORK</h2>
				</div>

				<div class="section-work_content">

					<div id="thumb-chauffeur-prive" class="pres-pr">
	<a id="href-pres-chauffeur-prive"></a>
	<div class="pres-pr_container_left">
		<div class="date f-mpl_m">
			<span>JUIN 2016</span>
		</div>
		<div class="title f-mpl_3" style="color:#54529F;font-size: 54px;">
			<h2>Chauffeur Privé</h2>
		</div>
		<div class="description f-sf_r">
			Nous avions pour objectif de revoir complètement l’identité graphique du site marketing afin qu’elle soit en adéquation avec la charte de la nouvelle application mobile. De plus, Chauffeur Privé est une application dont l’utilisation est quotidienne. Il fallait donc introduire des éléments « réels » dans un univers digital. C’est pourquoi nous avons utilisé des photos et des objets qui soient les plus réalistes possible. Enfin, à travers ce nouveau design, il était important de se rapprocher un peu plus de la cible de Chauffeur Privé, à savoir; être plus jeune, plus dynamique, plus intuitif.
		</div>
		<div class="more-details f-mpl_m">
			<a class="delay" href="https://dribbble.com/AgenceMe/projects/441215-Chauffeur-Priv">EN SAVOIR PLUS</a>
			<div></div>
			<svg height="17" width="17" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17">
			    <path stroke-linejoin="miter" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 10.81 8.5 L 8.5 8.5 C 7.23 8.5 6.19 9.53 6.19 10.81" />
			    <path stroke-linejoin="miter" stroke-linecap="butt" stroke-width="1" fill="none" fill-rule="evenodd" d="M 1 8.5 C 1 12.64 4.36 16 8.5 16 C 12.64 16 16 12.64 16 8.5 C 16 4.36 12.64 1 8.5 1 C 4.36 1 1 4.36 1 8.5 L 1 8.5 Z M 1 8.5" />
			    <path stroke-linejoin="round" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 8.5 6.19 L 10.81 8.5 L 8.5 10.81" />
			</svg>
		</div>
	</div><div class="pres-pr_container_right">

		<img class="work-img-chauffeur-prive-1" src="img/work-chauffeur-prive/chauffeur-prive-1.jpg">

		<img class="work-img-chauffeur-prive-2" src="img/work-chauffeur-prive/chauffeur-prive-2.jpg">
		
	</div>
	
</div><div id="thumb-thoughtspot" class="pres-pr">
	<a id="href-pres-thoughtspot"></a>
	<div class="pres-pr_container_left">
		<div class="date f-mpl_m">
			<span>SEPTEMBRE 2014</span>
		</div>
		<div class="title f-mpl_3" style="color: #FD8743;font-size: 54px;">
			<h2>THOUGHTSPOT</h2>
		</div>
		<div class="description f-sf_r">
			C’est un produit très puissant et complexe, le challenge était donc de simplifier l’accès à l’information et d’exposer les fonctionnalités de manière ludique.<br>Le « dark » en fond s’est vite imposé à nous, il permet à l’utilisateur de rester concentré sur les actions. Nous avons donc choisi de mettre en avant les fonctionnalités et les atouts grâce aux illustrations colorées, afin qu’elles contrastent avec le fond. 
		</div>
		<div class="more-details f-mpl_m">
			<a class="delay" href="https://dribbble.com/BarthelemyChalvet/projects/241047-ThoughtSpot-com">EN SAVOIR PLUS</a>
			<div></div>
			<svg height="17" width="17" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17">
			    <path stroke-linejoin="miter" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 10.81 8.5 L 8.5 8.5 C 7.23 8.5 6.19 9.53 6.19 10.81" />
			    <path stroke-linejoin="miter" stroke-linecap="butt" stroke-width="1" fill="none" fill-rule="evenodd" d="M 1 8.5 C 1 12.64 4.36 16 8.5 16 C 12.64 16 16 12.64 16 8.5 C 16 4.36 12.64 1 8.5 1 C 4.36 1 1 4.36 1 8.5 L 1 8.5 Z M 1 8.5" />
			    <path stroke-linejoin="round" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 8.5 6.19 L 10.81 8.5 L 8.5 10.81" />
			</svg>
		</div>
	</div><div class="pres-pr_container_right">

		<img class="work-img-thoughtspot-1" src="img/work-thoughtspot/thoughtspot-1.jpg">

		<img class="work-img-thoughtspot-2" src="img/work-thoughtspot/thoughtspot-2.jpg">

		<img class="work-img-thoughtspot-3" src="img/work-thoughtspot/thoughtspot-3.jpg">
		
	</div>
	
</div><div id="thumb-orange" class="pres-pr">
	<a id="href-pres-orange"></a>
	<div class="pres-pr_container_left">
		<div class="date f-mpl_m">
			<span>JANVIER 2015</span>
		</div>
		<div class="title f-mpl_3" style="color:#91B1AC;font-size: 54px;">
			<h2>ORANGE LABS</h2>
		</div>
		<div class="description f-sf_r">
			Application Orange à destination des professionnels, desktop et mobile,qui permet de communiquer facilement, d’échanger des documents, d’organiser des réunions et des vidéos-conférences.<br>
			Pour ce projet, nous avons fourni une prestation complète, c’est à dire : Webdesign, intégration et développement back. Le but était de rendre l’application à la fois ludique et efficace. L’optimisation de l’expérience utilisateur était primordiale étant donné la complexité et densité des services proposés. Nous avons imaginé une interface claire et simple, intégrant de manière intuitive les nombreuses fonctionnalités offertes.
		</div>
		<div class="more-details f-mpl_m">
			<a class="delay" href="https://dribbble.com/AgenceMe/projects/441217-Orange-Labs">EN SAVOIR PLUS</a>
			<div></div>
			<svg height="17" width="17" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17">
			    <path stroke-linejoin="miter" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 10.81 8.5 L 8.5 8.5 C 7.23 8.5 6.19 9.53 6.19 10.81" />
			    <path stroke-linejoin="miter" stroke-linecap="butt" stroke-width="1" fill="none" fill-rule="evenodd" d="M 1 8.5 C 1 12.64 4.36 16 8.5 16 C 12.64 16 16 12.64 16 8.5 C 16 4.36 12.64 1 8.5 1 C 4.36 1 1 4.36 1 8.5 L 1 8.5 Z M 1 8.5" />
			    <path stroke-linejoin="round" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 8.5 6.19 L 10.81 8.5 L 8.5 10.81" />
			</svg>
		</div>
	</div><div class="pres-pr_container_right">

		<img class="work-img-orange-1" src="img/work-orange/orange-1.jpg">

		<img class="work-img-orange-2" src="img/work-orange/orange-2.jpg">
		
	</div>
	
</div>
					<a class="btn-style delay f-mpl_m" href="https://dribbble.com/AgenceMe">
						<span>PLUS DE PROJETS</span>
					</a>

				</div>

			</section>


			<section id="section-ourvision">

				<a id="href-our-vision"></a>

				<div class="section-ourvision_title f-mpl_1">
					<h2>OUR VISION</h2>
				</div>
				<div class="section-ourvision_subtitle f-mpl_3">
					<h3>THE FRENCH AGENCY</h3>
				</div>

				<div class="section-ourvision_text f-sf_r">
					<p>
						Créée en 2011, <strong>AgenceMe</strong> est une agence d’identité visuelle spécialisée dans le product design. Notre expertise porte tout particulièrement sur le design de site web, applications mobiles (iOS et Android), mise en page de présentations (Keynote et Powerpoint), ainsi que le développement (App et Front-end).<br>
						Notre vision du design est tout à fait singulière et la créativité est notre point fort.<br>
						L’identité visuelle doit être, selon nous, tout aussi puissante et esthétique qu’un objet, un paysage, une peinture,une photo… Nous sommes très exigeants et accordons beaucoup d’importance à l’harmonie visuelle. 
					</p><p>
						Mais enfin, ce qui nous anime le plus, est le fait d’allier le design à une utilisation et une ergonomie optimale et de rendre une interface la plus intuitive possible.<br>
						Forts de notre expérience étroite avec les Etats-Unis, nous en avons gardé la façon de travailler et la simplicité des relations. Nous mettons un point d’honneur à ce que nos clients soient satisfaits et heureux, et c’est pourquoi nous sommes très attentifs aux retours, aux ressentis et souhaitons être des plus réactifs.
					</p>
				</div>

				<a class="btn-style delay f-mpl_m" href="https://dribbble.com/BarthelemyChalvet">
					<span>EN SAVOIR PLUS</span>
				</a>
				
				<!--
				<video id="section-ourvision_video" src="">

				</video>-->

				<img class="section-ourvision_bg" src="img/our-vision-cover.png">

			</section>


			<section id="section-ext">

				<a id="href-ext"></a>

				<div class="section-ext_container_avis">
					
					<div class="btn-nav left">
						<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 15 14">
							<path d="M402.31 5126L396.15 5126C392.76 5126 390 5128.76 390 5132.15 " fill-opacity="0" fill="#ffffff" stroke-dasharray="0" stroke-linejoin="miter" stroke-linecap="round" stroke-opacity="1" stroke-miterlimit="50" stroke-width="1" transform="matrix(1,0,0,1,-389.5,-5119.5)"></path>
							<path d="M397 5120L403.15 5126.15L397 5132.3099999999995 " fill-opacity="0" fill="#ffffff" stroke-dasharray="0" stroke-linejoin="round" stroke-linecap="round" stroke-opacity="1" stroke-miterlimit="50" stroke-width="1" transform="matrix(1,0,0,1,-389.5,-5119.5)"></path>
						</svg>
					</div>
					<div class="btn-nav right">
						<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 14 14">
							<path d="M1044.31 4488L1038.1499999999999 4488C1034.7599999999998 4488 1031.9999999999998 4490.76 1031.9999999999998 4494.15 " fill-opacity="0" fill="#ffffff" stroke-dasharray="0" stroke-linejoin="miter" stroke-linecap="round" stroke-opacity="1" stroke-miterlimit="50" stroke-width="1" transform="matrix(1,0,0,1,-1031.5,-4481.5)"></path>
							<path d="M1038 4482L1044.15 4488.15L1038 4494.3099999999995 " fill-opacity="0" fill="#ffffff" stroke-dasharray="0" stroke-linejoin="round" stroke-linecap="round" stroke-opacity="1" stroke-miterlimit="50" stroke-width="1" transform="matrix(1,0,0,1,-1031.5,-4481.5)"></path>
						</svg>
					</div>


					<div class="list-avis">

						<div class="avis show">
							<div class="logo">
								<img src="img/logo/ThoughtSpot-logo-quote.png" alt="ThoughtSpot Logo" title="ThoughtSpot Logo">
							</div>
							<div class="text f-mpl_3">
								<div><span>«</span></div>
								<div><span> La</span></div>
								<div><span> créativité</span></div>
								<div><span> d’Agence Me</span></div>
								<div><span> nous</span></div>
								<div><span> a</span></div>
								<div><span> aidé</span></div>
								<div><span> à</span></div>
								<div><span> lancer</span></div>
								<div><span> notre</span></div>
								<div><span> entreprise !</span></div>
								<div><span> Nous</span></div>
								<div><span> recommandons</span></div>
								<div><span> Barthélémy</span></div>
								<div><span> et</span></div>
								<div><span> l’Agence</span></div>
								<div><span> pour</span></div>
								<div><span> leur</span></div>
								<div><span> force</span></div>
								<div><span> de</span></div>
								<div><span> travail.</span></div>
								<div><span> »</span></div>        
							</div>
							                  
							<div class="pp">
								<div style="background-image: url(img/pp/Anand-Raghavan.jpg)"></div>
							</div>
							<div class="name f-mpl_m">
								<span>Anand Raghavan</span>
							</div>
							<div class="job f-mpl_m">
								<span>Senior Director Product Management, ThoughtSpot</span>
							</div>
							<div href="" class="link f-mpl_m">
								<a href="">@raghavan_anand</a>
							</div>
						</div>

						<div class="avis">
							<div class="logo">
								<img src="img/logo/xola-logo-quote.png" alt="XOLA Logo" title="XOLA Logo">
							</div>
							<div class="text f-mpl_3">
								<div><span>«</span></div>
								<div><span> AgenceMe,</span></div>
								<div><span> ce sont</span></div>
								<div><span> des</span></div>
								<div><span> designers</span></div>
								<div><span> brillants.</span></div>
								<div><span> Je</span></div>
								<div><span> travaille</span></div>
								<div><span> avec</span></div>
								<div><span> eux</span></div>
								<div><span> depuis</span></div>
								<div><span> plus</span></div>
								<div><span> de</span></div>
								<div><span> 4</span></div>
								<div><span> ans</span></div>
								<div><span> et</span></div>
								<div><span> nous</span></div>
								<div><span> avons</span></div>
								<div><span> accompli</span></div>
								<div><span> de</span></div>
								<div><span> nombreux</span></div>
								<div><span> projets</span></div>
								<div><span> ensemble.</span></div>
								<div><span> Ils</span></div>
								<div><span> apportent</span></div>
								<div><span> beaucoup</span></div>
								<div><span> d’attention</span></div>
								<div><span> aux</span></div>
								<div><span> couleurs</span></div>
								<div><span> nuancées,</span></div>
								<div><span> aux espaces</span></div>
								<div><span> négatifs,</span></div>
								<div><span> à</span></div>
								<div><span> l’architecture</span></div>
								<div><span> de</span></div>
								<div><span> l’information</span></div>
								<div><span> - Ils</span></div>
								<div><span> sont</span></div>
								<div><span> difficiles</span></div>
								<div><span> à</span></div>
								<div><span> identifier,</span></div>
								<div><span> laissez-les</span></div>
								<div><span> faire.</span></div>
								<div><span> Ils</span></div>
								<div><span> font</span></div>
								<div><span> aussi</span></div>
								<div><span> partie</span></div>
								<div><span> des</span></div>
								<div><span> personnes</span></div>
								<div><span> les</span></div>
								<div><span> plus</span></div>
								<div><span> productives</span></div>
								<div><span> que</span></div>
								<div><span> je</span></div>
								<div><span> connaisse.</span></div>
								<div><span> »</span></div>    
							</div>

							                  
							          
							<div class="pp">
								<div style="background-image: url(img/pp/Scott-Zimmerman.jpg)"></div>
							</div>
							<div class="name f-mpl_m">
								<span>J. Scott Zimmerman</span>
							</div>
							<div class="job f-mpl_m">
								<span>Co-founder of Xola</span>
							</div>
						</div>

						<div class="avis">
							<div class="logo">
								<img src="img/logo/Orange-logo-quote.png" alt="Orange Logo" title="Orange Logo">
							</div>
							<div class="text f-mpl_3">
								<div><span>«</span></div>
								<div><span> Nous</span></div>
								<div><span> avons</span></div>
								<div><span> travaillé</span></div>
								<div><span> à</span></div>
								<div><span> 4</span></div>
								<div><span> reprises</span></div>
								<div><span> avec</span></div>
								<div><span> AgenceMe</span></div>
								<div><span> sur</span></div>
								<div><span> différents</span></div>
								<div><span> projet</span></div>
								<div><span> web</span></div>
								<div><span> et</span></div>
								<div><span> applications</span></div>
								<div><span> mobiles.</span></div>
								<div><span> Ce</span></div>
								<div><span> que</span></div>
								<div><span> nous</span></div>
								<div><span> avons</span></div>
								<div><span> appréciés,</span></div>
								<div><span> réactivité</span></div>
								<div><span> et</span></div>
								<div><span> qualité</span></div>
								<div><span> des</span></div>
								<div><span> designs.</span></div>
								<div><span> Effet</span></div>
								<div><span> 'Wow'</span></div>
								<div><span> garanti.</span></div>
								<div><span> »</span></div>        
							</div>
							<div class="pp">
								<div style="background-image: url(img/pp/Miguel-Labranche.jpg)"></div>
							</div>
							<div class="name f-mpl_m">
								<span>Miguel Labranche</span>
							</div>
							<div class="job f-mpl_m">
								<span>Product manager at Orange Labs</span>
							</div>
							<div href="" class="link f-mpl_m">
								<a href="">@miglabranche</a>
							</div>
						</div>

						<div class="avis">
							<div class="logo">
								<img src="img/logo/chauffeur-prive-logo-quote.png" alt="Chauffeur Prive Logo" title="Chauffeur Prive Logo">
							</div>
							<div class="text f-mpl_3">
								<div><span>«</span></div>
								<div><span> Rapide</span></div>
								<div><span> et</span></div>
								<div><span> (très)</span></div>
								<div><span> efficace,</span></div>
								<div><span> AgenceMe</span></div>
								<div><span> a su</span></div>
								<div><span> respecter</span></div>
								<div><span> nos</span></div>
								<div><span> nombreuses</span></div>
								<div><span> contraintes</span></div>
								<div><span> et</span></div>
								<div><span> collaborer</span></div>
								<div><span> avec</span></div>
								<div><span> tous</span></div>
								<div><span> les</span></div>
								<div><span> services</span></div>
								<div><span> de</span></div>
								<div><span> notre</span></div>
								<div><span> entreprise</span></div>
								<div><span> pour</span></div>
								<div><span> refaire</span></div>
								<div><span> complètement</span></div>
								<div><span> notre</span></div>
								<div><span> site</span></div>
								<div><span> vitrine !</span></div>
								<div><span> »</span></div>     
							</div>

							                        
							<div class="pp">
								<div style="background-image: url(img/pp/Remi-Bardoux.jpg)"></div>
							</div>
							<div class="name f-mpl_m">
								<span>Remi Bardoux</span>
							</div>
							<div class="job f-mpl_m">
								<span>Product Manager at Chauffeur-Privé</span>
							</div>
						</div>

						<div class="avis">
							<div class="logo">
								<img src="img/logo/engie-logo-quote.png" alt="Engie Logo" title="Engie Logo">
							</div>
							<div class="text f-mpl_3">
								<div><span>«</span></div>
								<div><span> Nous</span></div>
								<div><span> avions</span></div>
								<div><span> des</span></div>
								<div><span> idées,</span></div>
								<div><span> AgenceMe</span></div>
								<div><span> les</span></div>
								<div><span> a magnifiées.</span></div>
								<div><span> Ils</span></div>
								<div><span> travaillent</span></div>
								<div><span> avec</span></div>
								<div><span> la</span></div>
								<div><span> même</span></div>
								<div><span> passion</span></div>
								<div><span> que</span></div>
								<div><span> nous,</span></div>
								<div><span> le</span></div>
								<div><span> même</span></div>
								<div><span> degré</span></div>
								<div><span> d'exigence</span></div>
								<div><span> sur</span></div>
								<div><span> la</span></div>
								<div><span> qualité</span></div>
								<div><span> tout</span></div>
								<div><span> en</span></div>
								<div><span> restant</span></div>
								<div><span> à</span></div>
								<div><span> notre</span></div>
								<div><span> écoute.</span></div>
								<div><span> Bonus :</span></div>
								<div><span> ils</span></div>
								<div><span> sont</span></div>
								<div><span> super</span></div>
								<div><span> cools</span></div>
								<div><span> »</span></div>     
							</div>                       
							<div class="pp">
								<div style="background-image: url(img/pp/Olivier-Bertil.jpg)"></div>
							</div>
							<div class="name f-mpl_m">
								<span>Olivier Bertil</span>
							</div>
							<div class="job f-mpl_m">
								<span>PetitBus Co-founder at ENGIE</span>
							</div>
							<div href="" class="link f-mpl_m">
								<a href="">@obertil</a>
							</div>
						</div>

					</div>

				</div>

				<div class="section-ext_container_clt">
					<div class="logo">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"viewBox="0 0 50 51" style="enable-background:new 0 0 50 51;" xml:space="preserve">
							<path style="fill:#3B3B48" d="M0,50.5h50v-50H0V50.5z M47.5,36.7l-0.7,1.7l-0.7-1.7h-0.6V39H46v-1.9h0l0.8,1.9H47l0.8-1.9h0V39
							h0.4v-2.3H47.5z M43.3,36.7V37H44v2h0.4v-2h0.7v-0.3H43.3z M41.2,46.4c-2.1,0-3.3-1.3-3.3-3.6c0-2.3,1.2-3.6,3.2-3.6
							c2,0,3.2,1.3,3.2,3.5c0,0.1,0,0.2,0,0.4h-4.6c0,1.3,0.6,2,1.6,2c0.7,0,1.2-0.3,1.6-0.9l1.3,0.7C43.7,45.9,42.6,46.4,41.2,46.4z
							 M42.6,41.9c0-0.9-0.5-1.5-1.4-1.5c-0.8,0-1.3,0.5-1.4,1.5H42.6z M36.8,39.3v6.6c0,1.2-0.1,3.1-3.4,3.1c-1.4,0-2.6-0.5-2.9-1.7
							l1.8-0.3c0.1,0.3,0.3,0.7,1.3,0.7c0.9,0,1.4-0.5,1.4-1.5v-0.8l0,0c-0.3,0.5-0.7,1-1.8,1c-1.6,0-2.9-1.1-2.9-3.5
							c0-2.3,1.3-3.6,2.8-3.6c1.4,0,1.9,0.6,2,1l0,0l0.2-0.8H36.8z M33.6,44.8c1.4,0,1.5-1.4,1.5-2.3c0-1.1-0.5-2-1.5-2
							c-0.7,0-1.4,0.5-1.4,2C32.2,43.4,32.2,44.8,33.6,44.8z M22.8,39.5l1.5-0.2l0.2,0.8c0.9-0.6,1.5-1,2.4-1c1.4,0,2.2,0.8,2.2,2.3v4.8
							h-1.8v-4.5c0-0.9-0.2-1.2-0.9-1.2c-0.5,0-1.1,0.2-1.7,0.8v5h-1.8V39.5z M19.6,45.7c-0.7,0.5-1.5,0.7-2.3,0.7c-1.3,0-2.1-0.9-2.1-2
							c0-1.6,1.4-2.4,4.4-2.7v-0.4c0-0.5-0.4-0.8-1.1-0.8c-0.7,0-1.3,0.3-1.7,0.8l-1.2-0.7c0.6-0.9,1.6-1.4,3-1.4c1.8,0,2.8,0.8,2.8,2.1
							c0,0,0,5,0,5h-1.6L19.6,45.7z M17,44.2c0,0.5,0.3,0.9,0.8,0.9c0.6,0,1.1-0.2,1.7-0.7v-1.6C17.9,42.9,17,43.4,17,44.2z M10.9,39.3
							h1.7v0.8c0.3-0.4,1.2-1,1.9-1c0.1,0,0.2,0,0.2,0v1.7h-0.1c-0.8,0-1.7,0.1-1.9,0.7v4.6h-1.9V39.3z M6.2,46.5c-1.8,0-3.4-1.2-3.4-3.7
							c0-2.5,1.6-3.7,3.4-3.7c1.8,0,3.4,1.2,3.4,3.7C9.6,45.3,8,46.5,6.2,46.5z M6.2,40.7c-1.4,0-1.6,1.2-1.6,2.1c0,0.9,0.2,2.1,1.6,2.1
							c1.4,0,1.6-1.2,1.6-2.1C7.8,41.9,7.5,40.7,6.2,40.7z"/>
						</svg>

					</div>
					<div class="logo">
						<img src="img/logo/logo-omc.png" alt="Logo Oh My Cream !" title="Logo Oh My Cream !">
					</div>
					<div class="logo">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 45 62" style="enable-background:new 0 0 45 62;" xml:space="preserve">
							<path style="fill:#3B3B48" d="M17.3,27.1c-0.3,0.3-1.2,0.5-1.4,0.8c-0.4,0.6-1.2,1.9-1.9,2.5c-2.1,2-6.7,3-8.9,1.1
								c-0.1,0-0.1,0.1,0.1,0.6c0.2,1,1,3.5,0.7,4.1c0.2,0.7,0.4,0.4,0.8,0.8C7,37.4,7.1,38,7.4,38.2c0.3,0,0.7,0,1-0.1
								c0.1,0.2,0.1,0.4,0.2,0.6c0.4,0,0.9-0.1,1.3-0.1c0.2,0.1,1,0.4,1.2,0.5c0.5,0,1-0.1,1.5-0.1c1.1,0.3,2.1-0.2,3-0.8
								c0.5-0.4,1.1-0.3,1.6-0.7c0.7-0.6,1.6-1.7,2-2.5c1.1-1.9,0.7-6.5-0.3-7.6C18.5,27,18.1,27,17.3,27.1 M32.2,14.2
								c-2.8,0.4-4.5,1.3-5.5,2c-0.7,0.5-0.9,0.9-1.1,1.1c-0.2,0.2-0.3,0.7-0.2,1.2c0.1,0.5,0.3,1,0.7,1.3c3.4-0.3,9.3-0.5,10.5,2.4
								c0.1,0.4,0.2,0.6,0.2,0.7c1.1-0.3,0.3-0.2,2,0.1c0.4,0.1,1.3-0.2,1.9-0.3c0.3-0.1,0.4-0.3,0.4-0.3s-0.1-0.3,0-0.4c0,0,0.6,0,0.8-0.1
								c1.6-0.3,0.7-1,1.5-1.8C42.9,14.6,37.4,13.4,32.2,14.2 M26.1,25.8c-0.8,0.6-1.1,0.5-1.6,1.4c0,0,0.1,0.1,0,0.1
								c0.5,0.9,1.6,1.3,2.3,2c0.2,0.2,0.9,1.4,1.2,1.5c0.4,0.4,0.6,1.6,0.8,1.6c0.2,0.3,0,1.1,0.2,1.4c0,1.4-0.2,1.5-0.4,1.8
								c0,0.1,0.1,0.4,0.1,0.4c0.1,0.1,0.6,0.5,0.9,0.4c0.8,0,3.9,2.5,4.1,2.9c2.2,0.2,2.1-0.5,3.6-1.2c0.4-0.2,0.7,0,1-0.3
								c0.3-0.3,0.3-0.9,0.6-1.2C39.2,31.2,31.7,26,26.1,25.8 M23.5,6.4c0.1-1.2,0-3,0.9-3.8c0.3-1.3,2.3-1,2-1.8c-0.2-0.5-1.2-0.3-1.5-0.2
								c-0.3,0.1-3.1,1-4.2,1.1c-0.5-0.1-0.9-0.3-1.4-0.4c-1.8,0.2-2.8,1.6-3.7,2.7c-0.8,0.9-1.9,3.2-1,4.6c0,0.3-0.1,0.6-0.1,0.9l2,2.9
								c0.7,0.5,0.8,0.9,1.5,1.3c0.2,0.2,0.3,0.5,0.5,0.7c0.6,0.4,2.4,0.4,2.7,0.1c2.9,0.3,2.6-5.6,3.5-6.8C24.4,7.3,23.9,6.7,23.5,6.4
								 M11.1,23.9c0.6-0.2,1.6-0.2,2.2-0.5c0.9-0.4,3.9-2.5,2.9-4.2c-0.3-3.6-4.6-0.6-6.5-1.8c-1.9-0.2-4-3.8-4.5-5.3
								c-0.2-0.6-0.1-0.4-0.4-0.9c0,0-0.2,0.2-0.2,0.1C4,12,4.1,12.6,4,14.1c-0.2,0-0.5,0-0.7,0c0,0.6-0.1,0.9-0.4,1.2
								c-0.1,0.1-0.1,0.2-0.2,0.3c-0.5-0.2-0.2,0.1-0.4-0.3C0.6,15.3,0.8,17,0,18C0,21.2,6.4,25.1,11.1,23.9"/>
							<path style="fill:#3B3B48" d="M23.1,58c2.5,0,4.6-0.8,4.6-5.3c0-3.8-2.1-5.1-4.6-5.1h-1.3V58H23.1z M24.4,44.5
								c4.6,0,7.7,2.9,7.7,8.1c0,6.6-4.3,8.5-8.8,8.5h-6c0-0.4,0-1.3,0-2.5V47c0-1.2,0-2,0-2.5H24.4z"/>
							<path style="fill:#3B3B48" d="M38.7,58.6c0,1.2,0.1,2.5,0.1,2.5h-4.5c0,0,0-1.3,0-2.5V47c0-1.2,0-2.5,0-2.5h10.5v3.2
								c0,0-2.4-0.1-3.2-0.1h-3V51l3,0c0.6,0,2.5,0,2.5,0v3.1c0,0-1.7,0-2.5,0l-3,0V58.6z"/>
							<path style="fill:#3B3B48" d="M4.8,50.8c0.1-1,0.4-3.2,2.8-3.2c2.5,0,2.6,2.1,2.6,3.2V51c0,0-1.7,0-2.7,0c-1,0-2.8,0-2.8,0
								L4.8,50.8z M8.5,57.8c-2.1,0-3.7-1.4-3.7-3.6V54c0,0,3.9-0.1,5.2-0.1c2.2,0,3.2,0,4.9,0v-1.3c0-5.7-2.4-8.4-7.4-8.4
								C5.3,44.1,0,45,0,52.9c0,5.3,2.7,8.5,7.3,8.5c3.7,0,5.9-0.9,7.6-2.1c-0.2-0.3-1.6-2.7-1.7-3C12.2,57,10.6,57.8,8.5,57.8L8.5,57.8z"
								/>
						</svg>
					</div>
					<div class="logo">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 133 63" style="enable-background:new 0 0 133 63;" xml:space="preserve">
							<path style="fill:#3B3B48;" d="M5.2,59.9c1.3,0,2.2-0.2,2.8-0.4c0.3-0.1,0.3-0.1,0.3-0.3v-2c0-0.1-0.1-0.2-0.2-0.2h0
								c-0.8,0.1-1.4,0.2-2.6,0.2c-0.9,0-1.9-0.5-1.9-2.6V53c0-2.2,1-2.6,1.9-2.6c1.2,0,1.8,0.1,2.6,0.2l0,0c0.1,0,0.2-0.1,0.2-0.2v-2
								c0-0.2,0-0.3-0.3-0.3c-0.6-0.1-1.5-0.4-2.8-0.4c-3,0-4.8,2-4.8,5.2v1.7C0.4,58,2.2,59.9,5.2,59.9L5.2,59.9z"/>
							<path style="fill:#3B3B48;" d="M9.8,59.8h2.6c0.1,0,0.3-0.1,0.3-0.3v-8.9l0.1,0c0.5-0.1,1.1-0.2,1.8-0.2c1.4,0,2,0.6,2,1.9v7.3
								c0,0.1,0.1,0.3,0.3,0.3h2.6c0.1,0,0.3-0.1,0.3-0.3v-7.5c0-2.9-1.6-4.3-4.7-4.3c-0.8,0-1.6,0.1-2.1,0.3l-0.2,0v-2.9
								c0-0.1-0.1-0.3-0.3-0.3H9.8c-0.1,0-0.3,0.1-0.3,0.3v14.4C9.5,59.7,9.7,59.8,9.8,59.8"/>
							<path style="fill:#3B3B48;" d="M56.7,45c-0.7-0.1-1.6-0.2-2.3-0.2c-2.7,0-4,1.1-4,3.4v0.9h-3.9v-0.9c0-0.6,0.1-1,1-1h2.2
								c0.1,0,0.1,0,0.1-0.2v-2c0,0,0-0.1-0.2-0.1c-0.7-0.1-1.6-0.2-2.3-0.2c-2.7,0-4,1.1-4,3.4v11.3c0,0.1,0.1,0.3,0.3,0.3h2.6
								c0.1,0,0.3-0.1,0.3-0.3v-7.9h3.9v7.9c0,0.1,0.1,0.3,0.3,0.3h2.6c0.1,0,0.3-0.1,0.3-0.3v-7.9h3.1c0.1,0,0.3-0.1,0.3-0.3v-1.9
								c0-0.1-0.1-0.3-0.3-0.3h-3.1v-0.9c0-0.6,0.1-1,1-1h2.2c0.1,0,0.1,0,0.1-0.2v-2C56.9,45.1,56.9,45,56.7,45"/>
							<path style="fill:#3B3B48;" d="M96,54.5c0,1.2-0.2,2.8-2.1,2.8c-0.5,0-1.3-0.1-1.8-0.1l-0.1,0v-6.6l0.1,0c0.4-0.1,1.1-0.1,1.8-0.1
								c1.8,0,2.1,1.6,2.1,2.8V54.5z M93.9,47.7c-2,0-3.8,0.4-4.5,0.5c-0.5,0.1-0.5,0.2-0.5,0.2v13.7c0,0.4,0.1,0.5,0.3,0.5h2.6
								c0.1,0,0.3-0.1,0.3-0.3v-2.7l0.2,0c0.6,0.1,1.3,0.1,1.7,0.1c3.3,0,5.2-1.9,5.2-5.3V53C99.1,49.6,97.2,47.7,93.9,47.7L93.9,47.7z"/>
							<path style="fill:#3B3B48;" d="M105.4,47.7c-2,0-3.3,0.2-4.7,0.6c-0.5,0.2-0.5,0.4-0.5,0.5v10.6c0,0.1,0.1,0.3,0.3,0.3h2.6
								c0.1,0,0.3-0.1,0.3-0.3v-8.9l0.1,0c0.5-0.1,1.3-0.1,1.9-0.1c0.3,0,0.4-0.1,0.4-0.2V48C105.8,47.7,105.4,47.7,105.4,47.7"/>
							<path  style="fill:#3B3B48;" d="M109.8,51.3h-2.6c-0.1,0-0.3,0.1-0.3,0.3v7.9c0,0.1,0.1,0.3,0.3,0.3h2.6c0.1,0,0.3-0.1,0.3-0.3
								v-7.9C110.1,51.4,110,51.3,109.8,51.3"/>
							<path  style="fill:#3B3B48;" d="M109.8,47.8h-2.6c-0.1,0-0.3,0.1-0.3,0.3v2c0,0.1,0.1,0.3,0.3,0.3h2.6c0.1,0,0.3-0.1,0.3-0.3v-2
								C110.1,48,110,47.8,109.8,47.8"/>
							<path  style="fill:#3B3B48;" d="M122.3,48.1c0-0.2-0.1-0.2-0.2-0.2h-2.8c-0.1,0-0.2,0.1-0.3,0.3l-2.3,9l-2.3-9
								c0-0.2-0.2-0.3-0.3-0.3h-2.8c-0.1,0-0.2,0.1-0.2,0.2c0,0,0,0,0,0.1l2.6,9.6c0.5,1.7,0.6,2,1.6,2c0.1,0,1.1,0,1.3,0
								c0.2,0,1.2,0,1.3,0c1-0.1,1.1-0.3,1.6-2L122.3,48.1C122.3,48.1,122.3,48.1,122.3,48.1"/>
							<path  style="fill:#3B3B48;" d="M64.6,52.7l-4.1,0c0.1-1.9,1.2-2.3,2.1-2.3c0.5,0,0.8,0,1.4,0.1l0.7,0.1V52.7z M66.7,48.3
								c-1.1-0.3-2.5-0.6-4.1-0.6c-3.3,0-5.2,1.9-5.2,5.3v1.6c0,3.4,1.8,5.3,5.2,5.3c1.9,0,2.7-0.2,4-0.5l0.1,0c0.2-0.1,0.3-0.1,0.3-0.4
								v-1.8c0-0.1,0-0.2-0.2-0.2h-0.1c-0.8,0.1-2.6,0.2-4,0.2c-1.3,0-2-0.7-2.1-2.4l0,0h6.3c0.3,0,0.4-0.1,0.4-0.4v-5.7
								C67.2,48.5,67.2,48.4,66.7,48.3L66.7,48.3z"/>
							<path  style="fill:#3B3B48;" d="M84.9,47.8c-2,0-3.3,0.2-4.6,0.6c-0.5,0.2-0.5,0.4-0.5,0.5v10.6c0,0.1,0.1,0.3,0.3,0.3h2.6
								c0.1,0,0.3-0.1,0.3-0.3v-8.9l0.1,0c0.5-0.1,1.3-0.1,1.9-0.1c0.3,0,0.4-0.1,0.4-0.2V48C85.3,47.8,84.9,47.8,84.9,47.8"/>
							<path  style="fill:#3B3B48;" d="M36.7,59.9c2.2,0,3.6-0.2,4.9-0.6c0.5-0.2,0.5-0.4,0.5-0.5V48.2c0-0.2-0.1-0.3-0.3-0.3h-2.6
								c-0.1,0-0.3,0.1-0.3,0.3v9.1l-0.1,0c-0.5,0.1-1.1,0.2-1.8,0.2c-1.4,0-2-0.6-2-1.9v-7.5c0-0.1-0.1-0.3-0.3-0.3h-2.6
								c-0.1,0-0.3,0.1-0.3,0.3v7.5C32,58.5,33.6,59.9,36.7,59.9"/>
							<path  style="fill:#3B3B48;" d="M78.2,47.8h-2.6c-0.1,0-0.3,0.1-0.3,0.3v9.1l-0.1,0c-0.5,0.1-1.1,0.2-1.8,0.2c-1.4,0-2-0.6-2-1.9
								v-7.5c0-0.1-0.1-0.3-0.3-0.3h-2.6c-0.1,0-0.3,0.1-0.3,0.3v7.5c0,2.9,1.6,4.3,4.7,4.3c2.2,0,3.6-0.2,4.9-0.6c0.5-0.2,0.5-0.4,0.5-0.5
								V48.2C78.5,48,78.4,47.8,78.2,47.8"/>
							<g transform="translate(121.518987, 45.695376)">
								<g>
								</g>
								<defs>
									<filter id="Adobe_OpacityMaskFilter_chauffeur-prive" filterUnits="userSpaceOnUse" x="0.9" y="0.9" width="9.9" height="13.3">
										<feColorMatrix  type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"/>
									</filter>
								</defs>
								<mask maskUnits="userSpaceOnUse" x="0.9" y="0.9" width="9.9" height="13.3" id="mask-2-chauffeur-prive">
									<g style="filter:url(#Adobe_OpacityMaskFilter_chauffeur-prive);">
										<polygon style="fill:#FFFFFF;" points="10.8,14.2 10.8,0.9 0.9,0.9 0.9,14.2 			"/>
									</g>
								</mask>
								<path  style="mask:url(#mask-2-chauffeur-prive);fill:#3B3B48;" d="M8.2,7L4,7c0.1-1.9,1.2-2.3,2.1-2.3c0.5,0,0.8,0,1.4,0.1l0.7,0.1V7z M10.3,2.6
									C9.6,2.4,8.8,2.3,7.9,2.2l0.6-0.8c0,0,0-0.1,0-0.1c0-0.1-0.1-0.2-0.3-0.2H5.7c-0.2,0-0.4,0.1-0.5,0.4L4.8,2.2
									C2.3,2.6,0.9,4.4,0.9,7.3v1.6c0,3.4,1.8,5.3,5.2,5.3c1.9,0,2.7-0.2,4-0.5l0.1,0c0.2-0.1,0.3-0.1,0.3-0.4v-1.8c0-0.1,0-0.2-0.2-0.2
									h-0.1c-0.8,0.1-2.6,0.2-4,0.2c-1.3,0-2-0.7-2.1-2.3h6.3c0.3,0,0.4-0.1,0.4-0.4V3.1C10.8,2.8,10.8,2.7,10.3,2.6L10.3,2.6z"/>
							</g>
							<path  style="fill:#3B3B48;" d="M27.7,57.3l-0.2,0c-0.5,0.1-1.1,0.1-1.7,0.1c-1.4,0-2-0.3-2-1.4s0.6-1.4,2-1.4
								c0.6,0,1.2,0,1.7,0.1l0.2,0V57.3z M30.8,53v-1.2c0-2.9-1.4-4.1-4.9-4.1c-2.1,0-3.6,0.4-4,0.6c-0.3,0.1-0.3,0.2-0.3,0.4v1.7
								c0,0.1,0.1,0.2,0.2,0.2h0c0.5,0,2.8-0.3,4-0.3c1.4,0,1.9,0.7,1.9,1.9c-0.7-0.1-1.4-0.1-2.3-0.1c-2.9,0-4.4,1.3-4.6,3.7v0.3
								c0.2,2.5,1.8,3.7,4.6,3.7c0.1,0,0.2,0,0.4,0c0,0,0.1,0,0.1,0c0.1,0,0.1,0,0.2,0c0.3,0,0.6,0,0.9,0c0,0,0,0,0,0
								c1.1-0.1,1.9-0.2,2.7-0.4c0.2,0,0.4-0.1,0.6-0.1c0.5-0.1,0.5-0.2,0.5-0.5v-0.1V58v-4.2L30.8,53C30.8,53,30.8,53,30.8,53L30.8,53z"/>
							<path  style="fill:#3B3B48;" d="M76.3,35.9h-20c-4.4,0-8-3.6-8-8V8c0-4.4,3.6-8,8-8h20c4.4,0,8,3.6,8,8v20
								C84.3,32.3,80.7,35.9,76.3,35.9"/>
							<path  style="fill:#FFFFFF;" d="M66.4,31.5c-0.4,0-0.8-0.2-1.2-0.5l-2.7-2.5c-0.5-0.5-0.8-1.4-0.7-2.1l2.3-17.3l1.5,0.2l-2.3,17.3
								c0,0.2,0.1,0.6,0.3,0.8l2.7,2.5c0,0,0.1,0,0.2,0l2.7-2.5c0.2-0.2,0.3-0.6,0.3-0.8L67.1,9.3l1.5-0.2l2.3,17.3
								c0.1,0.7-0.2,1.6-0.7,2.1L67.5,31C67.2,31.3,66.8,31.5,66.4,31.5"/>
							<path  style="fill:#FFFFFF;" d="M64.3,8.3h4.1V6.9h-4.1V8.3z M68.6,9.9h-4.5c-0.8,0-1.4-0.6-1.4-1.4V6.6c0-0.8,0.6-1.4,1.4-1.4
								h4.5c0.8,0,1.4,0.6,1.4,1.4v1.9C70,9.3,69.4,9.9,68.6,9.9L68.6,9.9z"/>
							<path  style="fill:#FFFFFF;" d="M61.1,22.8c-0.2,0-0.4-0.1-0.5-0.1c-0.2-0.1-0.7-0.4-0.7-1.2v-2.8c0-0.6,0.2-1.5,0.6-2.1l3.4-6
								l1.4,0.8l-3.4,6c-0.2,0.3-0.3,0.9-0.3,1.3v1.9l1.2-0.9l1,1.3L62,22.5C61.7,22.7,61.4,22.8,61.1,22.8"/>
						</svg>
					</div>
					<div class="logo">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"viewBox="0 0 100 34" style="enable-background:new 0 0 100 34;" xml:space="preserve">
							<g transform="translate(23.985455, 6.530225)">
								<defs>
									<filter id="Adobe_OpacityMaskFilter" filterUnits="userSpaceOnUse" x="0.8" y="0.5" width="30.8" height="48.1">
										<feColorMatrix  type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"/>
									</filter>
								</defs>
								<mask maskUnits="userSpaceOnUse" x="0.8" y="0.5" width="30.8" height="48.1" id="mask-2-xola">
									<g style="filter:url(#Adobe_OpacityMaskFilter);">
										<path style="fill:#FFFFFF;" d="M0.8,20.3c2.8,3.6,7.1,6,12,6c8.4,0,15.2-6.8,15.2-15.2c0-4.1-1.6-7.8-4.3-10.6H2
											C1.6,0.9,1.2,1.4,0.8,1.9V20.3L0.8,20.3z"/>
									</g>
								</mask>
								<path style="mask:url(#mask-2-xola);fill:#3B3B48;" d="M0.8,12.4c0,0,1.2-0.4,1.3-0.4c0.1,0,0.3,0,0.3,0s0.2-0.2,0.2-0.2c0.1,0,0.3,0.1,0.3,0
									c0-0.1,0.2-0.2,0.2-0.2c0.1,0,0-0.2,0.1-0.2C3.4,11.3,4,11,4.1,10.8C4.2,10.7,4.7,10,4.7,10C4.8,10,4.9,9.9,5,9.8
									C5,9.7,5.5,9.2,5.6,9.1C5.7,8.9,6,8.8,6,8.8S6,8.4,6,8.3C6.1,8.3,6.3,8,6.4,7.9c0.1-0.1,0.4-0.4,0.5-0.4c0.1,0,0.3,0,0.3-0.1
									c0-0.1,0-0.3,0.1-0.3c0.1,0,0.3-0.1,0.3-0.1s0.3-0.9,0.4-0.9C8.1,6.1,8.3,6,8.3,6s0.4-0.3,0.5-0.3c0.1,0,0.5,0,0.5,0
									s0.4-0.4,0.4-0.6C9.8,4.9,9.9,4.8,10,4.8c0.1,0-0.1-0.1,0.1-0.2c0.2-0.1,0.8-0.4,0.9-0.5c0.1-0.1,0.3-0.5,0.3-0.5S11.3,3.2,11.4,3
									c0.1-0.1,0.7-0.3,0.9-0.4C12.5,2.5,13,2.2,13.1,2c0.1-0.2,0.3-0.4,0.4-0.4c0.1,0,0.4-0.4,0.4-0.5c0.1-0.1,0.5-0.2,0.6-0.3
									c0.1-0.1,0.5-0.1,0.6-0.1c0.1,0,0.2-0.1,0.4-0.2c0.2,0,1,0,1,0c0.1,0,0.2-0.2,0.3-0.1c0.1,0.1,0.3,0.4,0.3,0.4
									c0.1,0,0.3,0.1,0.5,0.2c0.2,0.1,0.4,0.5,0.6,0.5c0.2,0,0.3,0.3,0.4,0.4c0.1,0.1,0.5,0.5,0.5,0.6c0,0.1-0.1,0.3,0,0.5
									c0.1,0.2,0.2,0.5,0.3,0.6c0.1,0.1,0.3,0.4,0.3,0.6c0,0.1,0.2,0.5,0.4,0.7c0.2,0.1,0.4,0.9,0.6,1.2c0.2,0.2,0.7,1.5,0.9,1.7
									C21.7,8.1,21.7,8,21.8,8c0.2,0.1,0.7,0.4,0.9,0.5c0.2,0.1,0.7,1.1,0.8,1.3c0.1,0.2,0.7,1.1,0.8,1.3c0.1,0.2,0.3,0.9,0.5,0.9
									c0.1,0,0.4,0.8,0.5,0.9c0.1,0.1,0.7,0.9,0.8,1c0.1,0.1,0.6,1.1,0.6,1.3c0.1,0.1,0.5,0.6,0.6,0.7c0.2,0,0.4,0.4,0.5,0.4
									c0.1,0,0.3,0.1,0.7,0.3c0.4,0.2,1.6,1,1.6,1s-0.2,0.3,0,0.3c0.1,0,0.3-0.1,0.4,0.1c0.1,0.1,0.1,0.5,0.3,0.6
									c0.2,0.1,0.6,0.5,0.7,0.5c0.1,0,0,29.5,0,29.5h-29L0.8,12.4z"/>
							</g>
							<path style="fill:#3B3B48;" d="M42.9,10.9c-0.1,0.1-0.2,0.3-0.2,0.4l0,0c0,0.1,0.1,0.3,0.1,0.4l0,0c0,0.1,0.1,0.4,0.1,0.4l0,0
								c0,0-0.2-0.1-0.3-0.2l0,0c-0.1-0.1-0.1-0.3-0.1-0.4l0,0c0-0.1-0.2,0.1-0.3,0.1l0,0c-0.1,0-0.1-0.1-0.2-0.2l0,0
								c0-0.1-0.1-0.2-0.1-0.2l0,0c-0.1,0-0.3,0.1-0.5,0.3l0,0c-0.2,0.2-0.2,0.3-0.3,0.3l0,0c-0.1,0.1-0.2,0.1-0.3,0l0,0
								c-0.1-0.1-0.1,0-0.1,0l0,0c0,0-0.1,0.1-0.1,0l0,0c-0.1,0,0,0.1,0,0.2l0,0c0.1,0.1,0.1,0.2,0.1,0.1l0,0c-0.1-0.1-0.1,0.2,0,0.3l0,0
								c0.1,0.1,0.2,0.3,0.3,0.5l0,0c0.1,0.2,0.5,1,0.4,1l0,0c-0.1,0-0.3-0.4-0.4-0.6l0,0c-0.1-0.2-0.3-0.4-0.4-0.4l0,0
								c-0.1,0-0.3,0-0.4-0.1l0,0c-0.1,0-0.6-0.2-0.8-0.1l0,0c-0.3,0-0.4-0.2-0.5-0.3l0,0c-0.1,0-0.6-0.2-0.7-0.2l0,0
								c-0.1,0,0.3,0.4,0.4,0.4l0,0c0.1,0,0.2,0.1,0,0.2l0,0c-0.2,0.1-0.5-0.2-0.6-0.2l0,0c-0.1,0-0.2,0.2-0.1,0.3l0,0
								c0.1,0.1,0.5,0.3,0.6,0.4l0,0c0.1,0.1,0,0.4-0.1,0.3l0,0c-0.1,0-0.6,0-0.8,0l0,0c-0.2,0.1-0.5-0.2-0.7-0.3l0,0
								c-0.2-0.1-0.3,0-0.4,0.1l0,0c-0.1,0.1-0.3,0.4-0.4,0.6l0,0c-0.1,0.1-0.7,0.1-0.8,0.2l0,0c-0.1,0.1-0.7,0.6-0.9,0.8l0,0
								c-0.2,0.2-0.7,0.3-0.8,0.5l0,0c-0.2,0.1-0.4,0.7-0.5,0.8l0,0c-0.1,0.1-0.3,0.3-0.5,0.5l0,0c-0.1,0.2-0.4,0.3-0.6,0.6l0,0
								c-0.2,0.2-0.3,0.4-0.3,0.4l0,0l-0.4,0.4L31,18.1c0,0-0.4,0.3-0.5,0.4l0,0c-0.1,0.1-0.6,0-0.8-0.1l0,0c-0.2,0-0.4,0.2-0.4,0.2l0,0
								c0.1,0,0.1,0.1,0.1,0.2l0,0c0,0.1-0.4,0.1-0.4,0.1l0,0l-0.1,0.3c0,0-0.3,0.1-0.5,0.1l0,0c-0.1,0-0.3,0.1-0.4,0.1l0,0
								c-0.1,0-0.3-0.2-0.4-0.2l0,0c-0.1,0-0.3-0.1-0.4,0l0,0c-0.1,0.1-0.3,0.4-0.3,0.4l0,0c0,0-0.3,0-0.3,0l0,0c-0.1,0-0.6,0.2-0.6,0.2
								l0,0l1.8,10.2c2.5,1.9,5.7,3,9.1,3l0,0c6.5,0,12-4.1,14.2-9.8l0,0c-0.4-0.7-1.1-1.9-1.2-2.1l0,0c-0.1-0.2-0.7-1.3-0.8-1.5l0,0
								c-0.1-0.1-0.2,0-0.3,0l0,0c0,0-0.1,0-0.1,0l0,0c-0.1,0-0.1,0-0.1,0l0,0c0,0.1-0.2,0.3-0.3,0.2l0,0c-0.1-0.1-0.3-0.6-0.3-0.7l0,0
								c0-0.1,0.3,0.1,0.3,0.1l0,0c0,0,0.1-0.1,0.1-0.1l0,0c0-0.1-0.5-0.2-0.5-0.2l0,0c-0.1,0-0.3-0.4-0.4-0.5l0,0
								c-0.1-0.1-0.4-0.5-0.5-0.6l0,0c-0.1-0.1-0.5-0.5-0.6-0.6l0,0c-0.1-0.1-0.4-0.4-0.6-0.5l0,0c-0.2-0.1-0.2-0.4-0.3-0.6l0,0
								c-0.1-0.2-0.1,0.1-0.1,0.2l0,0c0,0.1-0.2,0.2-0.1,0.2l0,0c0.1,0,0.1,0.2,0.2,0.3l0,0c0.1,0.1-0.2,0.2-0.3,0.1l0,0
								c-0.1,0-0.2-0.3-0.2-0.4l0,0c-0.1-0.1-0.3-0.2-0.2-0.3l0,0c0.1-0.1,0.2-0.4,0.1-0.5l0,0c-0.1-0.1-0.1-0.3,0-0.3l0,0
								c0.1,0,0.2-0.1,0.3-0.1l0,0c0.1-0.1,0.2,0.2,0.3,0.3l0,0c0.1,0.1,0.3,0.5,0.3,0.4l0,0c0-0.1,0.1-0.1,0.1-0.1l0,0
								c0.1,0.3,1.3,1.8,1.3,1.9l0,0c0,0.1,0.1-0.1,0.1-0.2l0,0c0-0.2,0.1-0.1,0.1-0.2l0,0c0-0.1-0.1-0.3-0.4-0.3l0,0
								c-0.3,0-0.4-0.4-0.5-0.6l0,0c-0.1-0.2,0.3,0.2,0.3,0.2l0,0l-0.8-1.4c0,0-0.7-1.2-0.8-1.2l0,0c-0.1,0-0.2,0.1-0.2,0.1l0,0
								c0,0.1,0.1,0.5,0.2,0.6l0,0c0.1,0.1,0.2,0.3,0.2,0.4l0,0c-0.1,0-0.3-0.1-0.5-0.2l0,0c-0.1-0.1-0.3,0.2-0.3,0.2l0,0
								c0,0-0.1-0.7-0.1-0.7l0,0c-0.1,0-0.1-0.3,0-0.6l0,0c0-0.3-0.3-0.3-0.3-0.3l0,0c0,0-0.1-0.6-0.1-0.7l0,0c-0.1-0.1,0-0.5,0-0.7l0,0
								c0-0.2-0.4-0.8-0.5-0.9l0,0c0,0-0.1-0.1-0.2-0.1l0,0C43,10.9,42.9,10.9,42.9,10.9"/>
							<g transform="translate(26.581818, 11.970225)">
								<path style="fill:#3B3B48;" d="M7.2,0.8c0,0-0.1,0.2-0.2,0.3l0,0C6.9,1.2,6.8,1.5,6.6,1.7l0,0C6.5,1.9,6.3,2,6.2,1.9l0,0
									C6.1,1.9,5.9,2,5.9,2.2l0,0c0,0.2,0.1,0.6,0,0.6l0,0c-0.1-0.1,0-0.3-0.2-0.2l0,0C5.5,2.7,5.2,3.3,5.1,3.2l0,0C5,3.2,4.8,2.9,4.7,3
									l0,0C4.7,3.1,4.6,3.5,4.5,3.3l0,0C4.4,3.1,4.3,3.2,4,3.3l0,0C3.8,3.5,3.5,3.7,3.4,3.7l0,0C3.3,3.8,3,4,3,4.2l0,0
									C2.9,4.3,2.8,4.4,2.7,4.5l0,0C2.6,4.5,2.4,4.7,2.4,4.8l0,0c0,0.1-0.1,0.2-0.3,0.3l0,0C2,5.2,1.8,5.4,1.6,5.5l0,0
									C1.5,5.7,1.2,6,1,6.1l0,0C0.9,6.1,0.6,6.3,0.8,6.3l0,0c0,0,0.2,0,0.4-0.1l0,0c0.1-0.1,0.5-0.4,0.6-0.4l0,0c0.1,0,0.3-0.1,0.4,0.1
									l0,0c0.1,0.1,0,0.3-0.2,0.4l0,0C1.9,6.3,1.7,6.6,1.6,6.6l0,0c-0.1,0-0.3,0.2-0.3,0.2l0,0c0,0,0.3,0,0.5-0.1l0,0
									C2,6.6,2.4,6.4,2.5,6.3l0,0C2.5,6.1,2.6,6,2.7,5.8l0,0C2.8,5.7,3,5.9,2.9,6l0,0c0,0.1,0.2,0.2,0.3,0l0,0C3.4,5.9,3.6,6,3.7,6l0,0
									c0.2,0,0.5,0.1,0.6,0l0,0c0.1-0.1,0.3-0.6,0.4-0.6l0,0c0.1-0.1,0.4-0.6,0.5-0.8l0,0c0.1-0.2,0.4-0.8,0.5-1l0,0
									C5.7,3.2,6,2.9,6.1,2.8l0,0c0.1-0.1,0.5-0.2,0.6-0.3l0,0C6.9,2.4,6.8,2.3,7,2.1l0,0C7.2,2,7.2,2,7.2,1.8l0,0c0-0.2,0.1-0.3,0.1-0.3
									l0,0c0,0-0.2-0.2-0.1-0.4l0,0C7.4,1,7.6,0.6,7.6,0.6l0,0c0,0,0-0.2-0.1-0.1l0,0c-0.1,0.1-0.3,0-0.3,0l0,0V0.8z"/>
							</g>
							<g transform="translate(42.283636, 16.668407)">
								<path style="fill:#3B3B48;" d="M0.6,0.6c0,0,0.6,0.8,0.7,1c0.1,0.2,0.5,1,0.6,1.1C1.9,2.8,2,3,2.2,3.2c0.2,0.2,0.4,0.4,0.4,0.4
									s0-0.2,0-0.3c0-0.1-0.5-0.6-0.6-0.9C1.9,2.2,0.7,0.6,0.6,0.6"/>
								<path style="fill:#3B3B48;" d="M2.8,3.8c0,0,0.2,0.3,0.2,0.5c0,0.2,0.2,0.6,0.3,0.8c0.1,0.2,0.2,0.5,0.3,0.5
									c0.1,0,0.3,0.1,0.5,0.3c0.2,0.2,0.3,0.4,0.5,0.5c0.2,0.1,0.3,0.1,0.3,0.1S4.6,6.1,4.4,5.7C4.1,5.3,3.7,4.5,3.5,4.4
									C3.4,4.3,3.2,4.1,3.2,4.1C3.1,4.2,2.8,3.8,2.8,3.8"/>
							</g>
							<path style="fill:#3B3B48;" d="M28.6,26.3c0.2,0.5,2,1.2,2,0.9l0,0c0-0.3,0-1.1,0-1.6l0,0c0.1,0.2,0.3,0.4,0.3,0.5l0,0
								c0.1,0.2,1.8,2.6,1.9,3l0,0c0.2,0.5,3.6,2.7,3.9,3.1l0,0c0.1,0.1,0.3,0.3,0.5,0.6l0,0c1.3,0,2.5-0.2,3.6-0.6l0,0
								c-0.1-0.1-0.2-0.2-0.2-0.3l0,0c0-0.1,0.1-0.2,0.2-0.3l0,0c0.1-0.1,0.1-0.1-0.1-0.1l0,0c-0.1,0-0.5-0.1-0.7-0.1l0,0
								c-0.2,0-0.9-0.4-1.2-0.5l0,0c-0.2-0.1-0.5-0.6-0.7-0.8l0,0c-0.2-0.2-0.3-0.2-0.4-0.2l0,0c-0.1,0-0.2,0-0.3-0.2l0,0
								c-0.1-0.2-0.1-0.3-0.2-0.4l0,0c-0.1-0.1-0.1,0.2-0.1,0.2l0,0c-0.1,0-0.2-0.3-0.3-0.4l0,0c-0.1-0.1-0.2-0.4-0.3-0.5l0,0
								c-0.1-0.1-0.1,0.1-0.1,0.2l0,0c0,0.1-0.2,0.2-0.3,0.2l0,0c-0.1-0.1-0.2-0.3-0.3-0.4l0,0c0,0,0,0.1,0,0.2l0,0c0,0.1,0,0.2,0,0.1l0,0
								c-0.1-0.1-0.2-0.2-0.2-0.3l0,0c0-0.1-0.1-0.6-0.2-0.6l0,0c-0.1,0-0.1-0.3-0.2-0.4l0,0c-0.1-0.1-0.1,0.1-0.1,0.2l0,0
								c0,0.1-0.2,0-0.2-0.1l0,0c0-0.1-0.1-0.4-0.2-0.4l0,0c-0.1-0.1-0.2,0.1-0.2,0.1l0,0l0,0.5c0,0-0.2-0.5-0.2-0.6l0,0
								c-0.1-0.1-0.2-0.4-0.2-0.3l0,0c0,0.1-0.1-0.1-0.2-0.2l0,0c-0.1-0.1-0.2-0.3-0.2-0.2l0,0c0,0.1,0.1,0.5,0,0.5l0,0
								c-0.1-0.1-0.2-0.5-0.3-0.7l0,0c-0.1-0.2-0.5-0.5-0.5-0.5l0,0l-0.1-0.3c0,0-0.4,0-0.4-0.1l0,0c0-0.1-0.2-0.1-0.2,0l0,0
								c0,0.1-0.2,0-0.3,0l0,0c-0.1,0-0.3-0.4-0.4-0.5l0,0c0-0.1-0.1-0.2-0.1-0.1l0,0c0,0.1-0.1,0-0.2-0.1l0,0c-0.1-0.2,0.1-0.4,0.2-0.5
								l0,0c0-0.1,0-0.2-0.1-0.1l0,0c-0.1,0.1-0.2,0.4-0.2,0.4l0,0l-0.2-0.3l-0.1,0.1L30.5,24l-0.2-0.3l-0.1,0.4l0,0
								c-0.1-0.2-0.1-0.4-0.2-0.4l0,0c-0.1-0.1-0.4-1.1-0.5-1.2l0,0c-0.1-0.2-0.1-0.5-0.1-0.5l0,0c0,0-0.2-0.1-0.4-0.1l0,0
								c-0.1,0.1-0.2-0.2-0.4-0.3l0,0c-0.1-0.1-0.3,0-0.3,0l0,0v-0.4l-1-0.1C27.4,21,28.4,25.8,28.6,26.3"/>
							<path style="fill:#3B3B48;" d="M25.1,16.7c-0.1,0.1-0.5,0.2-0.6,0.2l0,0c-0.1,0.1-0.3,0.3-0.3,0.4l0,0c-0.1,0.1-0.2,0.1-0.3,0.2
								l0,0c-0.1,0.1-0.2,0.4-0.2,0.4l0,0c0,0-0.2,0-0.5,0.3l0,0c-0.2,0.2-0.5,0.3-0.7,0.5l0,0c-0.2,0.1-0.5,0.4-0.7,0.5l0,0
								c0.8,7.7,7.2,13.6,15.1,13.6l0,0c0.4,0,0.8,0,1.2-0.1l0,0c-0.2-0.3-0.3-0.5-0.5-0.7l0,0c-0.3-0.6-1.1-1-1.2-1l0,0
								c-0.1,0-0.4-0.6-0.5-0.6l0,0c-0.1,0-0.4-0.5-0.5-0.7l0,0c-0.1-0.2-0.3-0.3-0.4-0.3l0,0c-0.2,0-0.9-1-0.9-1l0,0c0,0-1.1-1.2-1.2-1.3
								l0,0c-0.1-0.1-0.7-0.9-0.8-1l0,0c-0.1-0.1-0.6-0.5-0.8-0.5l0,0c-0.1,0-0.5-0.6-0.6-0.7l0,0c-0.1-0.1-0.3-0.1-0.3,0l0,0
								c0,0.1-0.2,0.3-0.2,0.3l0,0c0,0.1,0,0.3-0.1,0.4l0,0c-0.1,0.1-0.2,0.5-0.2,0.5l0,0c0,0-0.2-0.2-0.3-0.2l0,0c-0.1,0-0.2-0.6-0.2-0.7
								l0,0c0-0.1-0.2-0.4-0.2-0.5l0,0c-0.1-0.1-0.3-0.6-0.5-0.7l0,0c-0.1-0.1-0.2-0.6-0.3-0.8l0,0c0-0.2-0.4-0.8-0.5-1l0,0
								c-0.1-0.2-0.2-0.8-0.2-0.9l0,0c0-0.1-0.2-0.4-0.3-0.6l0,0c-0.1-0.1-0.6-0.7-0.8-0.8l0,0c-0.2-0.1-0.3-0.4-0.3-0.5l0,0
								c0-0.1-0.1-0.4-0.1-0.4l0,0c0,0-0.1-0.2-0.2-0.3l0,0c0-0.1-0.1-1.7-0.1-1.8l0,0c0-0.1-0.2-0.2-0.3-0.3l0,0c-0.1,0,0-0.2,0-0.3l0,0
								c0-0.1-0.1-0.2-0.1-0.2l0,0C25.5,16.3,25.2,16.6,25.1,16.7"/>
							<g transform="translate(0.000000, 0.101135)">
								<g transform="translate(0.000000, 0.989091)">
									<defs>
										<filter id="Adobe_OpacityMaskFilter_1_" filterUnits="userSpaceOnUse" x="0.6" y="0.5" width="19.6" height="31.5">
											<feColorMatrix  type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"/>
										</filter>
									</defs>
									<mask maskUnits="userSpaceOnUse" x="0.6" y="0.5" width="19.6" height="31.5">
										<g style="filter:url(#Adobe_OpacityMaskFilter_1_);">
											<polygon style="fill:#FFFFFF;" points="0.6,0.5 0.6,32 20.2,32 20.2,0.5 				"/>
										</g>
									</mask>
									<polygon style="mask:url(#mask-4);fill:#3B3B48;" points="0.9,0.5 3.1,0.5 10.4,14.1 17.6,0.5 19.8,0.5 11.6,15.9 20.2,32 18,32 10.4,17.8 
										2.8,32 0.6,32 9.2,15.9 		"/>
								</g>
								<polygon style="fill:#3B3B48;" points="60.4,31.1 69.6,31.1 69.6,33 58.4,33 58.4,1.5 60.4,1.5 	"/>
								<g transform="translate(72.945455, 0.000000)">
									<path style="fill:#3B3B48;" d="M20.1,20.8L13.9,5.6L20.1,20.8z M13.9,5.6L7.8,20.8h12.3L13.9,5.6z M7,22.7L2.8,33h-2L13.9,0.5
										L27.1,33h-2l-4.2-10.4H7z"/>
								</g>
								<path style="fill:#3B3B48;" d="M22.6,17.3c0,7.8,6.5,14.3,14.3,14.3c7.8,0,14.3-6.6,14.3-14.3C51.2,9.5,44.7,3,36.9,3
									C29,3,22.6,9.5,22.6,17.3 M53.2,17.3c0,8.8-7.5,16.2-16.3,16.2c-8.8,0-16.3-7.3-16.3-16.2c0-8.8,7.4-16.2,16.3-16.2
									C45.7,1.1,53.2,8.4,53.2,17.3"/>
							</g>
						</svg>
					</div>
					<div class="logo">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
							 viewBox="0 0 132 61" style="enable-background:new 0 0 132 61;" xml:space="preserve">
							<path style="fill:#3B3B48;" d="M130.6,48.1H122c-0.4,0-0.7,0.3-0.7,0.6c0,0.3,0.3,0.6,0.7,0.6h3.6v10.1c0,0.4,0.3,0.7,0.7,0.7
								c0.4,0,0.7-0.3,0.7-0.7V49.4h3.6c0.4,0,0.7-0.3,0.7-0.6C131.2,48.4,130.9,48.1,130.6,48.1L130.6,48.1z M119.6,54.1
								c0,2.7-2,4.9-4.8,4.9c-2.8,0-4.9-2.2-4.9-4.9v0c0-2.7,2-4.9,4.8-4.9C117.6,49.2,119.6,51.4,119.6,54.1L119.6,54.1L119.6,54.1z
								 M114.8,47.9c-3.8,0-6.3,2.9-6.3,6.2v0c0,3.3,2.5,6.1,6.3,6.1c3.8,0,6.3-2.9,6.3-6.2v0C121.1,50.8,118.5,47.9,114.8,47.9L114.8,47.9
								z M105.9,52c0,1.6-1.3,2.6-3.4,2.6h-3.1v-5.3h3.1C104.6,49.4,105.9,50.2,105.9,52L105.9,52L105.9,52z M102.7,48.1h-3.9
								c-0.4,0-0.7,0.3-0.7,0.7v10.7c0,0.4,0.3,0.7,0.7,0.7c0.4,0,0.7-0.3,0.7-0.7v-3.6h3c2.6,0,4.9-1.3,4.9-3.9v0
								C107.3,49.5,105.5,48.1,102.7,48.1L102.7,48.1z M92.1,53.4c-2.7-0.6-3.4-1.2-3.4-2.3v0c0-1.1,1-1.9,2.6-1.9c1.1,0,2.2,0.3,3.2,1
								c0.1,0.1,0.2,0.1,0.4,0.1c0.4,0,0.7-0.3,0.7-0.6c0-0.3-0.2-0.4-0.3-0.5c-1.1-0.8-2.3-1.2-3.9-1.2c-2.4,0-4.1,1.4-4.1,3.3v0
								c0,2,1.3,2.8,4.2,3.4c2.6,0.5,3.2,1.2,3.2,2.3v0c0,1.2-1.1,2-2.8,2c-1.6,0-2.7-0.5-3.9-1.4c-0.1-0.1-0.2-0.2-0.4-0.2
								c-0.4,0-0.7,0.3-0.7,0.7c0,0.2,0.1,0.4,0.3,0.5c1.4,1.1,2.9,1.6,4.7,1.6c2.5,0,4.2-1.3,4.2-3.4v0C96.1,55,94.8,54,92.1,53.4
								L92.1,53.4z M85,48.1h-8c-0.7,0-1.3,0.5-1.3,1.2c0,0.7,0.6,1.2,1.3,1.2h2.6v8.3c0,0.7,0.6,1.3,1.4,1.3c0.8,0,1.4-0.6,1.4-1.3v-8.3
								H85c0.7,0,1.3-0.5,1.3-1.2C86.2,48.7,85.7,48.1,85,48.1L85,48.1z M73.3,48c-0.8,0-1.4,0.6-1.4,1.3v3.5h-5v-3.5
								c0-0.7-0.6-1.3-1.4-1.3c-0.8,0-1.4,0.6-1.4,1.3v9.5c0,0.7,0.6,1.3,1.4,1.3c0.8,0,1.4-0.6,1.4-1.3v-3.6h5v3.6c0,0.7,0.6,1.3,1.4,1.3
								c0.8,0,1.4-0.6,1.4-1.3v-9.5C74.7,48.6,74.1,48,73.3,48L73.3,48z M61.1,53.2H58c-0.7,0-1.2,0.5-1.2,1.1c0,0.6,0.5,1.1,1.2,1.1h1.8
								v1.7c-0.7,0.5-1.6,0.7-2.6,0.7c-2.2,0-3.8-1.6-3.8-3.8v0c0-2,1.6-3.7,3.6-3.7c1.2,0,2,0.3,2.7,0.8c0.2,0.1,0.4,0.3,0.8,0.3
								c0.7,0,1.3-0.6,1.3-1.3c0-0.5-0.3-0.9-0.6-1.1c-1.1-0.8-2.4-1.2-4.2-1.2c-3.8,0-6.5,2.8-6.5,6.2v0c0,3.5,2.7,6.1,6.5,6.1
								c1.9,0,3.3-0.6,4.3-1.2c0.7-0.4,1-0.9,1-1.7v-2.9C62.5,53.8,61.9,53.2,61.1,53.2L61.1,53.2z M48,48c-0.8,0-1.4,0.6-1.4,1.3V55
								c0,1.9-1,2.9-2.7,2.9c-1.7,0-2.7-1-2.7-3v-5.5c0-0.7-0.6-1.3-1.4-1.3c-0.8,0-1.4,0.6-1.4,1.3v5.6c0,3.5,2,5.3,5.4,5.3
								c3.3,0,5.4-1.8,5.4-5.4v-5.5C49.3,48.6,48.7,48,48,48L48,48z M34.3,54.1c0,2-1.5,3.7-3.7,3.7s-3.8-1.7-3.8-3.8v0
								c0-2,1.5-3.7,3.7-3.7C32.8,50.3,34.3,52,34.3,54.1L34.3,54.1L34.3,54.1z M30.6,47.9c-3.8,0-6.6,2.8-6.6,6.2v0c0,3.4,2.7,6.1,6.6,6.1
								c3.8,0,6.6-2.8,6.6-6.2v0C37.2,50.7,34.4,47.9,30.6,47.9L30.6,47.9z M21.1,48c-0.8,0-1.4,0.6-1.4,1.3v3.5h-5v-3.5
								c0-0.7-0.6-1.3-1.4-1.3c-0.8,0-1.4,0.6-1.4,1.3v9.5c0,0.7,0.6,1.3,1.4,1.3c0.8,0,1.4-0.6,1.4-1.3v-3.6h5v3.6c0,0.7,0.6,1.3,1.4,1.3
								c0.8,0,1.4-0.6,1.4-1.3v-9.5C22.5,48.6,21.9,48,21.1,48L21.1,48z M9.7,48.1h-8c-0.7,0-1.3,0.5-1.3,1.2c0,0.7,0.6,1.2,1.3,1.2h2.6
								v8.3c0,0.7,0.6,1.3,1.4,1.3c0.8,0,1.4-0.6,1.4-1.3v-8.3h2.6c0.7,0,1.3-0.5,1.3-1.2C10.9,48.7,10.3,48.1,9.7,48.1L9.7,48.1z
								 M66.7,0.6C56,0.6,47.3,9.3,47.3,20.1c0,10.8,8.7,19.5,19.4,19.5c10.7,0,19.4-8.7,19.4-19.5C86.1,9.3,77.4,0.6,66.7,0.6L66.7,0.6z"
								/>
							<g transform="translate(56.081933, 15.652174)">
								<g transform="translate(0.124224, 3.220534)">
									<defs>
										<filter id="Adobe_OpacityMaskFilter" filterUnits="userSpaceOnUse" x="0.3" y="0.6" width="20.5" height="4.5">
											<feColorMatrix  type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"/>
										</filter>
									</defs>
									<mask maskUnits="userSpaceOnUse" x="0.3" y="0.6" width="20.5" height="4.5" id="mask-2">
										<g style="filter:url(#Adobe_OpacityMaskFilter);">
											<polygon style="fill:#FFFFFF;" points="0.3,5.1 20.8,5.1 20.8,0.6 0.3,0.6 "/>
										</g>
									</mask>
									<path style="mask:url(#mask-2-thoughtspot);fill:#FEFEFE;" d="M18.5,0.6H14c-0.4,0-0.7,0.3-0.7,0.7s0.3,0.7,0.7,0.7h4.6c0.5,0,0.9,0.4,0.9,0.9
										c0,0.5-0.4,0.9-0.9,0.9H1C0.6,3.7,0.3,4,0.3,4.4c0,0.4,0.3,0.7,0.7,0.7h17.6c1.2,0,2.3-1,2.3-2.3C20.8,1.6,19.8,0.6,18.5,0.6"/>
								</g>
								<g transform="translate(0.000000, 0.114944)">
									<defs>
										<filter id="Adobe_OpacityMaskFilter_1_toughtspot" filterUnits="userSpaceOnUse" x="0.2" y="0.5" width="20.7" height="4.6">
											<feColorMatrix  type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"/>
										</filter>
									</defs>
									<mask maskUnits="userSpaceOnUse" x="0.2" y="0.5" width="20.7" height="4.6" id="mask-4-toughtspot">
										<g style="filter:url(#Adobe_OpacityMaskFilter_1_toughtspot);">
											<polygon style="fill:#FFFFFF;" points="20.9,5.2 20.9,0.5 10.6,0.5 0.2,0.5 0.2,5.2 "/>
										</g>
									</mask>
									<path style="mask:url(#mask-4-toughtspot);fill:#FEFEFE;" d="M2.5,5h5c0.4,0,0.7-0.3,0.7-0.7S7.8,3.7,7.4,3.7h-5C2,3.7,1.6,3.3,1.6,2.8S2,1.9,2.5,1.9h7.6v2.6
										c0,0.4,0.3,0.7,0.7,0.7c0.4,0,0.7-0.3,0.7-0.7V1.9h8.8c0.4,0,0.7-0.3,0.7-0.7c0-0.4-0.3-0.7-0.7-0.7H2.5c-1.2,0-2.3,1-2.3,2.3
										C0.2,4,1.2,5,2.5,5"/>
								</g>
							</g>
						</svg>

					</div>
					<div class="logo">
						<img src="img/logo/study.png" alt="Logo Study Quizz" title="Logo Study Quizz">
					</div>
					<div class="logo">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"viewBox="0 0 98 47" style="enable-background:new 0 0 98 47;" xml:space="preserve">
							<path  style="fill:#3B3B48;" d="M36.4,37.8c0.2,0.1,0.3,0.3,0.2,0.5v0c-0.2,0.4-0.4,0.8-0.7,1.2c-0.2,0.4-0.4,0.8-0.7,1.2
								c-0.2,0.4-0.5,0.8-0.7,1.2c-0.2,0.4-0.5,0.8-0.8,1.2c0,0.1-0.1,0.1-0.1,0.2c0,0,0,0.1-0.1,0.1c0,0.1-0.1,0.1-0.1,0.2
								c0,0-0.1,0.1-0.1,0.1c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.2,0.2-0.3,0.3c-0.1,0.1-0.2,0.2-0.3,0.3
								c-0.2,0.2-0.4,0.4-0.6,0.5c-0.2,0.2-0.5,0.4-0.7,0.5C30.8,46,30.7,46,30.5,46c-0.2,0-0.4,0-0.6,0c-0.2,0-0.4-0.1-0.6-0.2
								c-0.2-0.1-0.3-0.2-0.5-0.3c-0.1-0.1-0.3-0.2-0.4-0.4c0-0.1-0.1-0.1-0.1-0.2c0-0.1-0.1-0.1-0.1-0.2C28.2,44.5,28,44.3,28,44
								c0-0.1-0.1-0.3-0.1-0.4c0-0.1-0.1-0.3-0.1-0.4c0-0.1-0.1-0.3-0.1-0.4c0-0.1,0-0.3,0-0.4l-0.1-0.8c-0.1-1,0-2,0.1-3
								c0.1-0.6,0.2-1.2,0.3-1.8c-0.4,0.1-0.8,0.1-1.2,0.1c-0.6,0-1.2,0-1.9-0.1c-0.5-0.1-1-0.2-1.4-0.3c0,0,0,0-0.1,0.1c0,0,0,0,0,0.1
								c-0.1,0.3-0.2,0.5-0.4,0.7c-0.1,0.1-0.1,0.3-0.2,0.4c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3
								c0,0.1-0.1,0.1-0.1,0.2c0,0.1-0.1,0.1-0.1,0.2c0,0.1-0.1,0.2-0.2,0.3c0,0.1-0.1,0.1-0.2,0.1c-0.1,0-0.2,0-0.3-0.1
								c-0.1-0.1-0.2-0.3-0.1-0.5c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.2,0.2-0.3
								c0.1-0.1,0.1-0.3,0.2-0.4c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.2,0.2-0.5,0.3-0.7c0,0,0,0,0-0.1c-0.2-0.1-0.5-0.3-0.7-0.4
								c-0.2-0.2-0.5-0.3-0.7-0.5c-0.3-0.2-0.5-0.5-0.7-0.8c-0.2-0.4-0.4-0.7-0.5-1.1c-0.1-0.4-0.1-0.8-0.1-1.2c0-0.4,0.2-0.8,0.4-1.2
								c0.1-0.1,0.1-0.1,0.2-0.3c0,0,0.1-0.1,0.1-0.1c0,0,0.1-0.1,0.1-0.1c0.1-0.1,0.1-0.1,0.2-0.2c0.1-0.1,0.2-0.1,0.3-0.2
								c0.2-0.1,0.3-0.2,0.5-0.2c0.2,0,0.3-0.1,0.5-0.1h0.3h0.1h0h0h0.1c0.1,0,0.1,0,0.2,0c0.1,0,0.2,0,0.3,0c0.1,0,0.1,0,0.2,0.1
								c0.1,0,0.2,0,0.3,0.1c0.1,0,0.2,0.1,0.2,0.1c0.1,0,0.2,0.1,0.3,0.1c0.1,0.1,0.1,0.1,0.2,0.2c0.1,0.1,0.1,0.1,0.2,0.2
								c0.1,0.1,0.1,0.2,0.1,0.2c0,0.1,0.1,0.2,0.1,0.3c0,0.1,0.1,0.2,0.1,0.2c0,0.1,0,0.2,0.1,0.2v0.3c0,0.1,0,0.1,0,0.2
								c0,0.1,0,0.2,0,0.3v0.2c0,0.1,0,0.2,0,0.2c0,0.1,0,0.1,0,0.2c0,0.1,0,0.2-0.1,0.4h0.6c0.8,0,1.7-0.1,2.6-0.3c0.2,0,0.4-0.1,0.7-0.1
								c0.2-0.1,0.4-0.1,0.7-0.2c0.2-0.1,0.4-0.2,0.6-0.2c0.2-0.1,0.5-0.2,0.7-0.2l0.6-0.1c0.5-0.1,0.9,0,1.4,0.3c0.4,0.3,0.7,0.7,0.8,1.2
								c0.1,0.4,0,0.7-0.1,1c-0.1,0.3-0.3,0.6-0.6,0.8c-0.3,0.2-0.5,0.5-0.8,0.8c-0.1,0.2-0.2,0.3-0.3,0.5c-0.1,0.2-0.2,0.3-0.3,0.5
								c-0.4,0.7-0.7,1.4-1,2.3c-0.1,0.2-0.1,0.4-0.2,0.6C30,40,30,40.2,29.9,40.5c0,0.1,0,0.2-0.1,0.3c0,0.1,0,0.2-0.1,0.3
								c0,0.1,0,0.2-0.1,0.3c0,0.1,0,0.2,0,0.3c0,0.2-0.1,0.4-0.1,0.6c0,0.2,0,0.4,0,0.6c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3
								c0,0.2,0.1,0.3,0.1,0.5c0.1,0.2,0.1,0.3,0.2,0.3c0,0,0,0.1,0.1,0.1c0,0,0,0,0,0c0,0,0,0,0.1,0c0,0,0,0,0.1,0h0.1h0.1
								c0,0,0.1,0,0.1,0c0.1,0,0.1,0,0.2-0.1c0.1,0,0.2-0.1,0.3-0.1c0.2-0.1,0.3-0.2,0.5-0.3c0.2-0.1,0.3-0.2,0.5-0.4l0.5-0.5
								c0,0,0.1-0.1,0.1-0.1c0-0.1,0.1-0.1,0.1-0.1c0-0.1,0.1-0.1,0.2-0.3c0.6-0.7,1.1-1.5,1.6-2.2c0.1-0.2,0.3-0.4,0.4-0.6
								c0.1-0.2,0.2-0.4,0.3-0.6c0.1-0.2,0.2-0.4,0.3-0.6c0.1-0.2,0.2-0.4,0.3-0.6c0-0.1,0.1-0.2,0.2-0.2C36.2,37.8,36.3,37.8,36.4,37.8
								 M21.9,31.6c0,0.1,0.1,0.3,0.2,0.4c0.1,0.1,0.2,0.2,0.3,0.3l0.3,0.3c0.1,0,0.1,0.1,0.2,0.1c0.1,0,0.1,0.1,0.2,0.1
								c0.1,0.1,0.2,0.1,0.4,0.2c0.1,0,0.3,0.1,0.4,0.1c0-0.2,0.1-0.3,0.1-0.4v-0.2c0-0.1,0-0.1,0-0.2c0-0.1,0-0.1,0-0.2V32
								c0-0.3,0-0.5-0.1-0.6c0-0.1-0.1-0.2-0.1-0.2C23.7,31,23.6,31,23.6,31c-0.1-0.1-0.3-0.1-0.5-0.1c0,0-0.1,0-0.1,0c-0.1,0-0.1,0-0.2,0
								v0h0h0h0c0,0,0,0-0.1,0c0,0-0.1,0-0.1,0c0,0,0,0-0.1,0c-0.2,0.1-0.3,0.2-0.4,0.3C22,31.3,22,31.4,22,31.5
								C21.9,31.5,21.9,31.6,21.9,31.6"/>
							<path  style="fill:#3B3B48;" d="M42,12.6c0.2,1.2,0.1,2.4-0.1,3.6c-0.1,0.6-0.2,1.2-0.4,1.7c-0.2,0.6-0.4,1.1-0.6,1.6
								c-0.1,0.3-0.3,0.5-0.4,0.8c-0.1,0.2-0.3,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.5,0.7c-0.2,0.2-0.4,0.5-0.6,0.7c-0.2,0.2-0.4,0.5-0.6,0.7
								c-0.2,0.2-0.4,0.4-0.6,0.6l-0.6,0.5l-0.6,0.5c-0.4,0.3-0.9,0.6-1.3,0.9c-0.5,0.2-0.9,0.5-1.4,0.7c-0.5,0.2-1,0.4-1.5,0.6
								c-0.5,0.1-1,0.3-1.5,0.4c-0.5,0.1-1,0.3-1.5,0.3c-0.5,0.1-0.9,0.2-1.4,0.2c-1.9,0.3-3.9,0.3-5.8,0c-0.5-0.1-0.7-0.3-0.6-0.8
								c0.1-0.4,0.3-0.6,0.6-0.7c1.8-0.2,3.6-0.6,5.2-1.2c0.8-0.3,1.6-0.6,2.3-1c0.8-0.5,1.5-0.9,2-1.4c0.6-0.5,1.2-1.1,1.7-1.7
								c0.1-0.1,0.1-0.2,0.2-0.2c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.1,0.2-0.2c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.2-0.3,0.3-0.4
								c0.1-0.2,0.2-0.3,0.3-0.5c0.7-1.3,1.2-2.7,1.3-4c0.1-0.3,0.1-0.6,0.1-1c0-0.3,0-0.7,0-1c0-0.3-0.1-0.6-0.1-1c0-0.3-0.1-0.7-0.2-1
								c-0.1-0.3-0.2-0.6-0.3-1c-0.1-0.3-0.3-0.7-0.4-1C34.9,9.1,34.9,9,34.8,9c0-0.1-0.1-0.2-0.1-0.3c-0.1-0.1-0.2-0.3-0.3-0.5
								c-0.2-0.3-0.4-0.6-0.6-0.9c-0.5-0.6-1.1-1.2-1.7-1.7c-0.6-0.5-1.3-0.9-2.1-1.4c-0.4-0.2-0.8-0.4-1.2-0.5c-0.4-0.1-0.8-0.3-1.2-0.4
								c-0.4-0.1-0.8-0.3-1.3-0.4c-0.4-0.1-0.9-0.2-1.3-0.3c-0.4-0.1-0.9-0.2-1.3-0.3c-0.4-0.1-0.9-0.2-1.3-0.2c-0.2,0-0.5,0-0.7,0
								c-0.2,0-0.4-0.1-0.6-0.1h-1.4h-1.3c-0.2,0-0.5,0-0.7,0c-0.2,0-0.4,0-0.6,0c-0.5,0.1-0.9,0.1-1.3,0.2c-0.4,0.1-0.9,0.1-1.3,0.2
								c-0.9,0.2-1.8,0.4-2.6,0.7c-0.8,0.3-1.7,0.6-2.5,1C8.8,4.3,8.4,4.6,8.1,4.8C7.7,5,7.3,5.2,6.9,5.5C6.6,5.8,6.3,6,5.9,6.3
								C5.6,6.6,5.3,6.9,5,7.2C4.4,7.9,3.9,8.6,3.4,9.4c-0.3,0.7-0.6,1.5-0.8,2.4c0,0.2-0.1,0.5-0.1,0.7v0.6v0.2v0.1v0.3c0,0.1,0,0.2,0,0.3
								c0,0.1,0,0.2,0,0.3c0.1,0.8,0.3,1.6,0.6,2.4c0.4,0.8,0.8,1.5,1.2,2c0.5,0.6,1,1.2,1.6,1.7c0.1,0.1,0.3,0.3,0.4,0.4
								c0.2,0.1,0.3,0.2,0.5,0.3c0.2,0.1,0.3,0.2,0.5,0.3c0.2,0.1,0.3,0.2,0.5,0.3c0.3,0.2,0.7,0.4,1,0.5c0.1,0.1,0.2,0.1,0.3,0.1
								c0.1,0,0.2,0,0.3,0.1c0.2,0.1,0.3,0.1,0.3,0.1l0.1,0l0.1,0c0.6,0.2,1.1,0.6,1.4,1.2c0.3,0.6,0.3,1.2,0.1,1.8
								c-0.2,0.6-0.6,1.1-1.2,1.4c-0.6,0.3-1.2,0.3-1.8,0.1L8.3,27L8.2,27L8,26.9c-0.2-0.1-0.3-0.1-0.4-0.2c-0.1-0.1-0.2-0.1-0.3-0.2
								c-0.1-0.1-0.2-0.2-0.3-0.2c-0.2-0.1-0.5-0.3-0.7-0.4c-0.2-0.1-0.4-0.3-0.6-0.4c-0.2-0.2-0.4-0.3-0.6-0.5c-0.2-0.2-0.4-0.3-0.6-0.5
								c-0.2-0.2-0.4-0.4-0.6-0.6c-0.2-0.2-0.3-0.4-0.5-0.6c-0.7-0.8-1.3-1.7-1.8-2.7C1.2,20,1,19.5,0.7,19c-0.2-0.5-0.3-1-0.4-1.5
								c-0.1-0.5-0.2-1-0.2-1.6c0-0.6,0-1.1,0-1.6l0.1-0.8v-0.2c0-0.1,0-0.1,0-0.2l0-0.2l0-0.2c0.1-0.3,0.1-0.5,0.2-0.7
								c0.1-0.3,0.2-0.5,0.3-0.7c0.2-0.5,0.4-1,0.6-1.4C1.7,9.5,1.9,9,2.2,8.6C2.7,7.8,3.3,7.1,4,6.4c0.3-0.4,0.6-0.7,1-1
								C5.4,5,5.8,4.7,6.2,4.4C7,3.8,7.9,3.3,8.7,2.9c0.8-0.4,1.7-0.8,2.6-1.1c0.5-0.2,0.9-0.3,1.3-0.4C13.1,1.2,13.6,1.1,14,1
								c0.9-0.2,1.8-0.4,2.8-0.5c0.2,0,0.5-0.1,0.7-0.1c0.2,0,0.5-0.1,0.7-0.1l1.4-0.1c0.2,0,0.5,0,0.7,0c0.3,0,0.5,0,0.7,0
								c0.2,0,0.5,0,0.7,0c0.3,0,0.5-0.1,0.7-0.1c0.5,0,1,0,1.4,0c0.5,0,0.9,0,1.4,0c0.5,0,1,0.1,1.5,0.1c0.5,0,1,0.1,1.5,0.2
								c0.5,0.1,1,0.2,1.4,0.3c0.5,0.1,1,0.2,1.5,0.4c1,0.3,1.9,0.7,2.9,1.2c0.9,0.4,1.8,1,2.7,1.7c0.2,0.1,0.4,0.3,0.6,0.5
								c0.2,0.2,0.4,0.3,0.6,0.5c0.1,0.1,0.2,0.2,0.3,0.3c0.1,0.1,0.2,0.2,0.3,0.3c0.1,0.1,0.2,0.2,0.3,0.3c0.1,0.1,0.2,0.2,0.3,0.3
								c0.7,0.8,1.3,1.8,1.8,3C41.5,10.2,41.8,11.4,42,12.6z"/>
							<path style="fill:#3B3B48;" d="M21.6,39.5c-4.1,7.3-18.9-4.6-19-1.2c0,0.6,0.1,1.2,0.1,1.7c0.1,0.2,0.1,0.5,0.2,0.7
								c0.1,0.2,0.2,0.4,0.3,0.6c0.2,0.4,0.5,0.7,0.8,0.9c0.1,0.1,0.2,0.2,0.5,0.3c0.1,0,0.2,0.1,0.5,0.1c0.1,0,0.3,0,0.5,0
								c0.4,0,0.6,0,0.9,0c0.1,0,0.2-0.1,0.3-0.1c0.1,0,0.2-0.1,0.3-0.1c0.1,0,0.2-0.1,0.3-0.1c0.1-0.1,0.3-0.2,0.4-0.3
								c0.1-0.1,0.3-0.2,0.4-0.3c0.1-0.1,0.3-0.2,0.4-0.4c0.1-0.1,0.1-0.2,0.2-0.2c0.1-0.1,0.2-0.2,0.2-0.3c0.1-0.2,0.3-0.3,0.3-0.5
								c0.1-0.2,0.2-0.4,0.3-0.6c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.2,0.1-0.3c0.1-0.1,0.1-0.2,0.2-0.4
								c0.1-0.2,0.2-0.5,0.3-0.7c0.1-0.2,0.2-0.5,0.3-0.7c0.2-0.5,0.3-1,0.5-1.5c0.2-0.5,0.3-1,0.5-1.6l0.4-1.6c0.1-0.3,0.1-0.5,0.2-0.8
								c0.1-0.3,0.2-0.5,0.2-0.8c0.1-0.1,0.1-0.3,0.1-0.4c0-0.1,0.1-0.2,0.1-0.4c0.1-0.1,0.1-0.3,0.1-0.4c0-0.1,0.1-0.3,0.1-0.4l0.2-0.8
								l0.2-0.8L14,24c0.1-0.6,0.2-1.1,0.3-1.7c0.1-0.6,0.2-1.1,0.4-1.7c0.1-0.6,0.3-1.1,0.4-1.7c0.2-0.6,0.4-1.2,0.6-1.7
								c0.2-0.6,0.4-1.2,0.6-1.7c0.2-0.6,0.5-1.2,0.8-1.7c0-0.1,0.1-0.2,0.2-0.4c0-0.1,0.1-0.3,0.2-0.4c0.1-0.1,0.1-0.3,0.3-0.4
								c0.1-0.1,0.1-0.1,0.1-0.2c0-0.1,0.1-0.2,0.1-0.2l0.3-0.4c0.1-0.1,0.1-0.2,0.1-0.2c0.1-0.1,0.1-0.2,0.2-0.2l0.6-0.8
								c0.1-0.1,0.2-0.3,0.3-0.4c0.1-0.1,0.2-0.2,0.4-0.3c0.1-0.1,0.3-0.3,0.4-0.3c0.1-0.1,0.2-0.2,0.4-0.3c0.3-0.2,0.6-0.4,0.9-0.6
								C22,8.2,22.3,8,22.6,7.9c0.6-0.3,1.2-0.5,1.9-0.7C25.1,7.1,25.8,7,26.3,7c0.5,0,0.7,0.2,0.7,0.7c0,0.3-0.1,0.5-0.3,0.6
								c-0.2,0.2-0.5,0.3-0.7,0.5c-0.2,0.1-0.4,0.3-0.6,0.5c-0.4,0.3-0.8,0.7-1.1,1.1c-0.6,0.7-1.1,1.5-1.5,2.4c-0.4,0.8-0.7,1.8-0.9,2.8
								c-0.1,0.5-0.3,1-0.4,1.5c-0.1,0.5-0.2,1-0.3,1.6l-0.6,3.3c-0.1,0.6-0.2,1.1-0.3,1.7c-0.1,0.6-0.2,1.1-0.3,1.7L19.6,27
								c-0.1,0.3-0.1,0.6-0.2,0.9c-0.1,0.3-0.1,0.5-0.2,0.8c0,0.1-0.1,0.3-0.1,0.4c0,0.1-0.1,0.2-0.1,0.4l-0.2,0.9
								c-0.1,0.1-0.1,0.3-0.1,0.4c0,0.1-0.1,0.3-0.1,0.4c-0.1,0.1-0.1,0.3-0.1,0.4c0,0.1,0,0.3-0.1,0.4l-0.5,1.7c-0.1,0.3-0.2,0.6-0.3,0.9
								c-0.1,0.3-0.2,0.5-0.3,0.8l-0.6,1.7c-0.1,0.3-0.3,0.6-0.4,0.9c-0.1,0.3-0.2,0.6-0.4,0.8c-0.1,0.3-0.3,0.6-0.4,0.9
								c-0.1,0.3-0.3,0.5-0.4,0.8c-0.1,0.1-0.2,0.3-0.3,0.4c-0.1,0.1-0.2,0.2-0.3,0.4c-0.1,0.1-0.2,0.3-0.3,0.4c-0.1,0.1-0.2,0.2-0.3,0.4
								c-0.1,0.1-0.2,0.3-0.3,0.4c-0.1,0.1-0.2,0.2-0.3,0.4c-0.1,0.1-0.2,0.3-0.3,0.4c-0.1,0.1-0.2,0.2-0.4,0.4c-0.1,0.1-0.3,0.3-0.4,0.3
								c-0.1,0.1-0.2,0.2-0.4,0.4c-0.1,0.1-0.3,0.2-0.5,0.3c-0.1,0.1-0.3,0.2-0.5,0.3c-0.7,0.4-1.4,0.7-2.2,0.9c-0.2,0.1-0.4,0.1-0.6,0.1
								c-0.2,0-0.4,0.1-0.6,0.1H6.7c-0.1,0-0.2,0-0.3,0H6.2H6.1c-0.2,0-0.4-0.1-0.6-0.1c-0.2,0-0.4-0.1-0.6-0.1c-0.5-0.1-0.8-0.2-1.1-0.4
								c-0.3-0.2-0.6-0.4-1-0.6c-0.2-0.1-0.3-0.3-0.5-0.4c-0.1-0.1-0.2-0.3-0.4-0.4c-0.5-0.6-0.8-1.2-1-2c-0.2-0.8-0.2-1.5-0.2-2.1
								c0.1-0.7,0.2-1.3,0.5-2c0.1-0.3,0.3-0.6,0.4-0.9C1.8,37,2,36.7,2.2,36.5c2.4-2.3,14.8,8.6,18.8,2.6L21.6,39.5z"/>
							<path id="Path-280" style="fill:#3B3B48;" d="M10.5,38.6c0,0-0.4,0.3-0.5,0.5c-0.1,0.1-0.6,0.1-0.6,0.3c0,0.2,0.5,0.6,0.5,0.6l-0.1,1l4.8,0.6
								l0.6-0.3l0-1.6L10.5,38.6z"/>
							<path  style="fill:#3B3B48;" d="M35.3,43.3c0-0.2-0.1-0.3-0.1-0.5c0-0.2,0-0.3,0-0.5v-0.9c0-0.6,0.1-1.1,0.2-1.7
								c0-0.3,0.1-0.5,0.1-0.8c0-0.3,0.1-0.6,0.1-0.8c0.1-0.3,0.1-0.5,0.2-0.8c0.1-0.3,0.1-0.6,0.2-0.8c0.1-0.3,0.1-0.5,0.2-0.8
								c0.1-0.3,0.1-0.5,0.2-0.8c0.1-0.3,0.1-0.5,0.2-0.8c0.1-0.2,0.1-0.5,0.2-0.8l0.5-1.5l0.3-0.8l0.1-0.4c0-0.1,0.1-0.1,0.1-0.2
								c0-0.1,0-0.1,0.1-0.2c0.2-0.5,0.6-0.9,1-1.1c0.5-0.2,1-0.2,1.5,0c0.5,0.2,0.9,0.6,1.1,1c0.2,0.5,0.2,1,0,1.5c0,0,0,0,0,0.1h0
								l-0.1,0.3l-0.1,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c0,0.1-0.1,0.2-0.1,0.3c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7
								c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7
								c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.1,0.5-0.2,0.7c0,0.2-0.1,0.5-0.1,0.7
								c0,0.1,0,0.2-0.1,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3V43c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.2v0.1c0,0,0,0,0,0.1
								c0,0,0,0.1,0,0.1v0v0c0,0,0,0,0,0h0.1h0.1c0,0,0,0,0,0h0h0c0.1,0,0.1,0,0.1,0c0,0,0.1,0,0.2-0.1c0.1-0.1,0.3-0.2,0.5-0.3
								c0.2-0.1,0.4-0.3,0.5-0.4c0.1-0.1,0.2-0.2,0.3-0.2c0.1-0.1,0.2-0.2,0.3-0.3c0.3-0.3,0.7-0.7,1-1c0.2-0.2,0.3-0.4,0.5-0.5
								c0.2-0.2,0.3-0.4,0.5-0.6c0.1-0.2,0.3-0.5,0.6-0.8c0.3-0.3,0.5-0.6,0.6-0.8c0.1-0.1,0.2-0.2,0.2-0.3c0.1-0.1,0.2-0.2,0.3-0.3
								l0.2-0.3c0-0.1,0.1-0.1,0.1-0.2c0-0.1,0.1-0.1,0.1-0.1c0.1-0.1,0.2-0.2,0.3-0.2c0.1,0,0.3,0,0.4,0.1c0.2,0.2,0.2,0.3,0.1,0.6
								c0,0.1-0.1,0.1-0.1,0.2c0,0.1,0,0.1-0.1,0.2L45,38.9c-0.1,0.3-0.2,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.5,0.9c-0.2,0.4-0.4,0.6-0.5,0.9
								c-0.1,0.2-0.3,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.5,0.7c-0.1,0.2-0.3,0.4-0.5,0.6c-0.1,0.1-0.2,0.2-0.3,0.3
								c-0.1,0.1-0.2,0.2-0.3,0.3c-0.1,0.1-0.2,0.2-0.3,0.3c-0.1,0.1-0.2,0.2-0.3,0.3c-0.3,0.2-0.5,0.4-0.8,0.6c-0.1,0-0.1,0.1-0.2,0.1
								c-0.1,0.1-0.2,0.1-0.3,0.1c-0.1,0.1-0.4,0.1-0.6,0.2h-0.1h0l-0.1,0h-0.1c-0.1,0-0.2,0-0.3,0c-0.2,0-0.5,0-0.7-0.1
								c-0.1,0-0.2-0.1-0.4-0.1c-0.1,0-0.2-0.1-0.3-0.2c-0.2-0.2-0.4-0.3-0.6-0.5c-0.2-0.2-0.3-0.4-0.4-0.6c-0.1-0.2-0.2-0.4-0.3-0.6
								c-0.1-0.2-0.1-0.4-0.1-0.5C35.3,43.6,35.3,43.5,35.3,43.3 M42.8,25.3c-0.7,0-1.3-0.2-1.8-0.7c-0.5-0.5-0.7-1.1-0.7-1.8
								c0-0.7,0.2-1.3,0.7-1.8c0.5-0.5,1.1-0.7,1.8-0.7c0.7,0,1.3,0.2,1.7,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.7-0.2,1.3-0.7,1.8
								C44.1,25.1,43.5,25.3,42.8,25.3"/>
							<path  style="fill:#3B3B48;" d="M62,37.7c0.1,0.1,0.1,0.3,0.1,0.4C62,38.3,62,38.4,62,38.5l-0.2,0.3c0,0.1-0.1,0.1-0.1,0.3
								c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.1,0.2c-0.1,0.2-0.2,0.4-0.3,0.6c-0.1,0.2-0.2,0.4-0.3,0.6
								c-0.1,0.2-0.3,0.4-0.4,0.6c-0.1,0.2-0.2,0.4-0.4,0.6c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3
								c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.2-0.3,0.4-0.4,0.6c-0.1,0.2-0.3,0.3-0.4,0.5c-0.4,0.4-0.7,0.7-1.1,1c-0.1,0.1-0.2,0.2-0.3,0.3
								c-0.1,0.1-0.2,0.2-0.4,0.2c-0.1,0.1-0.3,0.1-0.4,0.2c-0.1,0.1-0.3,0.1-0.5,0.2c-0.1,0-0.2,0-0.3,0.1c-0.1,0-0.2,0-0.3,0h-0.3
								c-0.1,0-0.1,0-0.2,0c-0.1,0-0.1,0-0.2,0c-0.1,0-0.1,0-0.2-0.1c-0.1,0-0.1,0-0.2-0.1c-0.1,0-0.1-0.1-0.2-0.1c-0.1,0-0.1,0-0.2-0.1
								c-0.1-0.1-0.2-0.2-0.3-0.3c-0.1,0-0.1-0.1-0.2-0.2c0-0.1-0.1-0.1-0.1-0.2c-0.1-0.2-0.3-0.5-0.3-0.6c0-0.1-0.1-0.2-0.1-0.3
								c0-0.1,0-0.2-0.1-0.3c0-0.2-0.1-0.4-0.1-0.5c0-0.2,0-0.3,0-0.5c0-0.2,0-0.3,0-0.4c0-0.1,0-0.3,0-0.4c0-0.1,0-0.3,0.1-0.4
								c0-0.1,0-0.3,0.1-0.4c0-0.3,0.1-0.5,0.1-0.7c0.1-0.2,0.1-0.5,0.2-0.7l0.3-1.4c0.1-0.4,0.2-0.9,0.3-1.3c0.1-0.4,0.3-0.9,0.4-1.3
								c0.1-0.2,0.1-0.4,0.1-0.6c0.1-0.2,0.1-0.4,0.2-0.6c0.1-0.2,0.1-0.4,0.1-0.6c0.1-0.2,0.1-0.4,0.1-0.6c0-0.1,0-0.2,0.1-0.4
								c0,0-0.1,0-0.1,0c0,0,0,0,0,0c-0.1,0-0.2,0.1-0.3,0.1c-0.1,0-0.2,0.1-0.3,0.1c-0.1,0-0.2,0.1-0.3,0.1c-0.2,0.1-0.3,0.2-0.5,0.3
								c-0.2,0.1-0.3,0.2-0.5,0.4c-0.1,0.1-0.1,0.1-0.2,0.2c-0.1,0.1-0.1,0.2-0.2,0.2c-0.1,0.1-0.1,0.2-0.2,0.2c-0.1,0.1-0.1,0.2-0.2,0.2
								c-0.3,0.3-0.5,0.7-0.8,1c-0.2,0.3-0.5,0.7-0.7,1c-0.1,0.2-0.2,0.4-0.4,0.6c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3
								c-0.1,0.2-0.2,0.4-0.3,0.6c-0.1,0.2-0.2,0.4-0.3,0.6c-0.2,0.4-0.4,0.8-0.6,1.2c-0.2,0.4-0.4,0.8-0.5,1.2c-0.1,0.2-0.2,0.4-0.3,0.6
								c-0.1,0.2-0.2,0.4-0.3,0.6c0,0.1-0.1,0.2-0.1,0.3c0,0.1-0.1,0.2-0.1,0.3c0,0.1-0.1,0.2-0.1,0.3c0,0.1,0,0.2-0.1,0.3c0,0,0,0,0,0
								l-0.1,0.3c-0.1,0.5-0.4,1-0.8,1.3c-0.4,0.3-0.9,0.4-1.5,0.3c-0.5-0.1-1-0.4-1.3-0.8c-0.3-0.5-0.4-1-0.3-1.5c0-0.1,0-0.1,0-0.2
								l3.7-13.5c0.1-0.4,0.3-0.6,0.6-0.8c0.3-0.2,0.7-0.2,1-0.1c0.3,0.1,0.6,0.3,0.8,0.6c0.2,0.3,0.3,0.6,0.2,0.9l-1.5,8.1
								c0.1-0.2,0.1-0.4,0.2-0.6c0.1-0.2,0.1-0.4,0.2-0.6c0-0.1,0.1-0.2,0.1-0.3c0.1-0.1,0.1-0.2,0.1-0.3c0-0.1,0.1-0.2,0.1-0.3
								c0.1-0.1,0.1-0.2,0.1-0.3c0.2-0.4,0.4-0.8,0.6-1.2c0.2-0.4,0.4-0.8,0.6-1.2c0-0.1,0.1-0.2,0.1-0.3c0.1-0.1,0.1-0.2,0.2-0.3l0.3-0.6
								c0.1-0.2,0.3-0.4,0.4-0.6c0.1-0.2,0.3-0.5,0.4-0.7c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.1-0.2,0.2-0.3c0.1-0.1,0.2-0.2,0.3-0.3
								c0.1-0.1,0.2-0.2,0.3-0.3c0.2-0.2,0.4-0.4,0.7-0.6c0.2-0.2,0.5-0.4,0.8-0.5c0.1-0.1,0.3-0.1,0.4-0.2c0.2-0.1,0.3-0.1,0.5-0.2
								c0.1,0,0.2,0,0.3-0.1c0.1,0,0.2,0,0.3-0.1c0.1,0,0.2,0,0.3,0h0.1h0.1h0.1h0.1H56h0.1c0.1,0,0.2,0,0.2,0c0.1,0,0.2,0,0.3,0
								c0.1,0,0.2,0,0.3,0.1c0.2,0.1,0.4,0.1,0.6,0.3c0.1,0.1,0.3,0.2,0.5,0.4c0.1,0.1,0.2,0.2,0.2,0.2c0.1,0.1,0.1,0.2,0.2,0.2
								c0.1,0.1,0.1,0.2,0.1,0.3c0.1,0.1,0.1,0.2,0.1,0.3c0.1,0.2,0.2,0.3,0.2,0.5c0,0.1,0.1,0.3,0.1,0.4c0.1,0.3,0.1,0.5,0.1,0.7
								c0,0.2,0,0.4,0,0.6c0,0.3,0,0.6-0.1,0.9c0,0.1-0.1,0.3-0.1,0.4c0,0.1,0,0.3-0.1,0.4c0,0.1-0.1,0.3-0.1,0.4c0,0.1-0.1,0.2-0.1,0.4
								c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.2,0.4-0.3,0.6C58,36.6,58,36.8,57.9,37c-0.1,0.2-0.2,0.4-0.3,0.6c-0.2,0.4-0.4,0.8-0.6,1.2
								c-0.2,0.4-0.3,0.8-0.5,1.2L56,41.3c-0.1,0.4-0.3,0.7-0.4,1.2c-0.1,0.3-0.2,0.6-0.2,0.7c0,0.1,0.1,0.2,0.2,0.2c0.1,0,0.3-0.1,0.4-0.2
								c0.2-0.1,0.4-0.2,0.6-0.3c0.1-0.1,0.2-0.1,0.3-0.2c0.1-0.1,0.1-0.1,0.2-0.2l0.5-0.4c0.3-0.3,0.6-0.6,0.9-0.9
								c0.3-0.3,0.6-0.6,0.9-0.9c0.1-0.2,0.3-0.3,0.4-0.5c0.1-0.2,0.3-0.3,0.4-0.5c0.1-0.1,0.2-0.2,0.4-0.5c0.2-0.3,0.3-0.4,0.4-0.5
								l0.2-0.3l0.2-0.3h0C61.6,37.6,61.8,37.6,62,37.7"/>
							<path  style="fill:#3B3B48;" d="M78.8,24.8c0.1,0,0.2,0,0.3,0.1c0.1,0.1,0.1,0.2,0.1,0.3c0,0.1,0,0.2-0.1,0.3
								c-0.1,0.1-0.2,0.1-0.3,0.1l-9.9,1c0,0,0,0.1-0.1,0.1c-0.1,0.3-0.2,0.6-0.4,0.9c-0.1,0.3-0.2,0.6-0.4,0.9c-0.3,0.6-0.5,1.2-0.8,1.9
								c-0.3,0.6-0.5,1.2-0.8,1.8c-0.1,0.3-0.3,0.6-0.4,0.9c-0.1,0.3-0.3,0.6-0.4,0.9c-0.1,0.2-0.1,0.3-0.2,0.5c-0.1,0.2-0.2,0.3-0.3,0.5
								L65,35.5l-0.1,0.2l-0.1,0.1c0,0-0.1,0.1-0.1,0.1c0,0,0,0,0,0c0,0.1,0,0.2,0,0.2v0.2c0,0.3,0,0.6,0,0.9v0.9c0,0.6,0,1.2,0.1,1.8
								c0.1,0.6,0.1,1.2,0.3,1.7c0.1,0.5,0.3,0.9,0.6,1.3c0.1,0.2,0.3,0.3,0.4,0.4c0.1,0.1,0.3,0.2,0.4,0.2c0,0,0.1,0,0.1,0
								c0.1,0,0.1,0,0.1,0h0.3c0.2,0,0.4-0.1,0.6-0.2c0.1,0,0.2-0.1,0.3-0.1c0.1-0.1,0.2-0.1,0.3-0.2c0.1-0.1,0.2-0.2,0.3-0.3
								c0.1-0.1,0.2-0.2,0.3-0.3c0.1-0.1,0.2-0.2,0.3-0.3c0.1-0.1,0.2-0.2,0.3-0.3c0.1-0.1,0.2-0.2,0.3-0.3c0.1-0.1,0.2-0.3,0.3-0.4
								c0.1-0.1,0.2-0.3,0.3-0.4c0.1-0.1,0.1-0.3,0.2-0.4c0.1-0.2,0.2-0.3,0.2-0.4c0.1-0.1,0.1-0.3,0.2-0.4l0.4-0.8c0-0.1,0.1-0.1,0.1-0.2
								c0-0.1,0.1-0.2,0.1-0.2l0.1-0.2l0-0.1l0.1-0.1v0c0.1-0.2,0.2-0.3,0.3-0.3c0.1-0.1,0.3-0.1,0.4,0c0.1,0.1,0.2,0.2,0.3,0.3
								c0.1,0.1,0.1,0.2,0.1,0.4l0,0.1l0,0.1c0,0.1,0,0.1-0.1,0.3c0,0.1,0,0.2-0.1,0.3c0,0.1,0,0.1-0.1,0.2c0,0.2-0.1,0.3-0.1,0.5
								c-0.1,0.2-0.1,0.3-0.2,0.5c-0.1,0.2-0.1,0.3-0.2,0.5c-0.1,0.2-0.1,0.3-0.2,0.5l-0.4,0.9L70.9,43c-0.1,0.2-0.2,0.3-0.3,0.5
								c-0.1,0.2-0.2,0.3-0.3,0.5c-0.1,0.2-0.2,0.3-0.4,0.4c-0.1,0.1-0.2,0.3-0.4,0.4c-0.1,0.1-0.3,0.3-0.4,0.4c-0.1,0.1-0.3,0.3-0.5,0.4
								c-0.4,0.2-0.8,0.4-1.2,0.5c-0.1,0-0.2,0.1-0.3,0.1c-0.1,0-0.2,0-0.3,0.1c-0.1,0-0.2,0-0.3,0c-0.1,0-0.2,0-0.4,0
								c-0.1,0-0.2,0-0.3-0.1c-0.1,0-0.2,0-0.3-0.1c-0.3-0.1-0.5-0.2-0.7-0.3c-0.2-0.1-0.4-0.2-0.6-0.4c-0.2-0.2-0.4-0.3-0.5-0.5
								c-0.3-0.3-0.6-0.7-0.8-1c-0.2-0.3-0.4-0.7-0.5-1.1c0-0.1-0.1-0.2-0.1-0.3c0-0.1,0-0.2-0.1-0.3c-0.1-0.2-0.1-0.3-0.2-0.5
								c-0.1-0.4-0.2-0.7-0.3-1.1c-0.1-0.7-0.2-1.4-0.3-2.1c-0.1-0.7-0.1-1.4-0.1-2.1c0-0.7,0-1.4,0.1-2c0.1-0.7,0.1-1.4,0.2-2
								c0.2-1.3,0.4-2.7,0.7-4c0.1-0.2,0.1-0.5,0.2-0.7c0.1-0.2,0.1-0.5,0.2-0.7L52,27.2c-0.4,0-0.7-0.1-1-0.4c-0.3-0.3-0.4-0.6-0.4-1
								c0-0.4,0.1-0.7,0.4-1c0.3-0.3,0.6-0.5,1-0.5H52l11.2,0.3c0-0.1,0-0.1,0.1-0.2c0-0.1,0-0.1,0.1-0.2c0.2-0.7,0.4-1.3,0.7-1.9
								c0.3-0.6,0.5-1.3,0.8-1.9c0.1-0.3,0.3-0.6,0.5-0.9c0.2-0.3,0.3-0.6,0.5-0.9c0.1-0.2,0.2-0.3,0.3-0.4c0.1-0.2,0.2-0.3,0.3-0.5
								c0.1-0.2,0.2-0.3,0.3-0.4c0.1-0.1,0.2-0.3,0.4-0.4c0.1-0.1,0.3-0.3,0.4-0.4c0.1-0.1,0.3-0.3,0.5-0.4c0.1-0.1,0.2-0.1,0.3-0.2
								c0.1-0.1,0.2-0.1,0.3-0.2c0.1,0,0.2-0.1,0.3-0.1c0.1-0.1,0.2-0.1,0.3-0.1c0.1,0,0.2-0.1,0.3-0.1c0.1,0,0.3,0,0.4,0h0.1h0.1h0
								c0,0,0,0,0,0h0c0.1,0,0.2,0,0.2,0c0.1,0,0.2,0.1,0.4,0.1c0.1,0,0.2,0.1,0.2,0.1c0.1,0.1,0.1,0.1,0.2,0.2c0.1,0.1,0.2,0.2,0.3,0.4
								c0.1,0.2,0.2,0.5,0.2,0.7c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c0,0.2-0.1,0.4-0.1,0.5
								c0,0.2,0,0.3-0.1,0.5c0,0.2-0.1,0.3-0.1,0.5c0,0.2-0.1,0.3-0.1,0.5c0,0.1,0,0.2-0.1,0.2c0,0.1,0,0.2-0.1,0.3c0,0.1-0.1,0.2-0.1,0.3
								c0,0.1,0,0.1-0.1,0.2c-0.1,0.3-0.2,0.6-0.3,0.9c-0.1,0.3-0.2,0.6-0.3,0.9L69.9,24l-0.2,0.5l-0.2,0.5L78.8,24.8 M67.7,21.8
								c-0.2,0.5-0.4,1-0.5,1.5c-0.1,0.5-0.3,1-0.4,1.6l1.6,0c0-0.1,0.1-0.1,0.1-0.2c0-0.1,0-0.1,0.1-0.2c0.5-1.2,1-2.4,1.4-3.6
								c0-0.1,0.1-0.2,0.1-0.2c0-0.1,0-0.2,0.1-0.2c0-0.1,0-0.2,0.1-0.2c0-0.1,0-0.2,0.1-0.2c0-0.2,0.1-0.3,0.1-0.5c0-0.2,0.1-0.3,0.1-0.5
								c0.1-0.3,0.1-0.6,0.1-0.9c0-0.1,0-0.1,0-0.2c0-0.1,0-0.2,0-0.2c0-0.1,0-0.2-0.1-0.4c0-0.1-0.1-0.2-0.1-0.2h-0.1v0l0,0h0h0v0h0
								c-0.1,0-0.1,0.1-0.2,0.1c-0.2,0.1-0.3,0.3-0.4,0.5c0,0.1-0.1,0.1-0.1,0.2c0,0.1,0,0.1-0.1,0.2c-0.1,0.1-0.1,0.2-0.2,0.3
								c-0.1,0.2-0.2,0.5-0.4,0.8c-0.1,0.1-0.1,0.3-0.2,0.4l-0.2,0.4c-0.1,0.3-0.2,0.6-0.3,0.8C67.9,21.2,67.8,21.5,67.7,21.8 M66.7,27.9
								c0.1-0.2,0.2-0.4,0.3-0.6c0.1-0.2,0.3-0.4,0.4-0.6l-1.2,0c-0.1,0.4-0.2,0.8-0.3,1.2c-0.1,0.4-0.2,0.8-0.3,1.1c0,0.1-0.1,0.3-0.1,0.4
								c0,0.1,0,0.2-0.1,0.4c0.2-0.3,0.4-0.6,0.6-0.9C66.4,28.5,66.6,28.2,66.7,27.9"/>
							<path style="fill:#3B3B48;" d="M71.4,43c0-0.2-0.1-0.3-0.1-0.5c0-0.2,0-0.3,0-0.5v-0.9c0-0.6,0.1-1.1,0.2-1.7
								c0-0.3,0.1-0.5,0.1-0.8c0.1-0.3,0.1-0.6,0.1-0.8c0.1-0.3,0.1-0.5,0.2-0.8c0.1-0.3,0.1-0.6,0.2-0.8c0.1-0.3,0.1-0.5,0.2-0.8
								c0.1-0.3,0.1-0.5,0.2-0.8c0.1-0.3,0.1-0.5,0.2-0.8c0.1-0.2,0.1-0.5,0.2-0.8l0.5-1.5l0.3-0.8l0.1-0.4c0-0.1,0.1-0.1,0.1-0.2
								c0-0.1,0-0.1,0.1-0.2c0.2-0.5,0.6-0.9,1-1.1c0.5-0.2,1-0.2,1.5,0c0.5,0.2,0.9,0.6,1.1,1c0.2,0.5,0.2,1,0,1.5c0,0,0,0,0,0.1h0
								L77.5,32l-0.1,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c0,0.1-0.1,0.2-0.1,0.3c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7
								c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7c-0.1,0.2-0.2,0.5-0.3,0.7
								c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.1,0.5-0.2,0.7c0,0.2-0.1,0.5-0.1,0.7
								c0,0.1,0,0.2-0.1,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.2c0,0,0,0.1,0,0.1
								c0,0,0,0,0,0.1c0,0,0,0.1,0,0.1v0v0c0,0,0,0,0,0h0.1h0.1c0,0,0,0,0,0c0,0,0,0,0,0h0c0.1,0,0.1,0,0.1,0c0,0,0.1,0,0.2-0.1
								c0.1-0.1,0.3-0.2,0.5-0.3c0.2-0.1,0.4-0.3,0.5-0.4c0.1-0.1,0.2-0.2,0.3-0.2c0.1-0.1,0.2-0.2,0.3-0.3c0.3-0.3,0.7-0.7,1-1
								c0.2-0.2,0.3-0.4,0.5-0.5c0.2-0.2,0.3-0.4,0.5-0.6c0.1-0.2,0.3-0.5,0.6-0.8c0.3-0.3,0.5-0.6,0.6-0.8c0.1-0.1,0.2-0.2,0.2-0.3
								c0.1-0.1,0.2-0.2,0.3-0.3l0.2-0.3c0-0.1,0.1-0.1,0.1-0.2c0-0.1,0.1-0.1,0.1-0.1c0.1-0.1,0.2-0.2,0.3-0.2c0.1,0,0.3,0,0.4,0.1
								c0.2,0.2,0.2,0.3,0.1,0.6c0,0.1-0.1,0.1-0.1,0.2c0,0.1,0,0.1-0.1,0.2l-0.2,0.3c-0.1,0.3-0.2,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.5,0.9
								c-0.2,0.4-0.4,0.6-0.5,0.9c-0.1,0.2-0.3,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.4,0.7c-0.1,0.2-0.3,0.5-0.5,0.7c-0.1,0.2-0.3,0.4-0.5,0.6
								c-0.1,0.1-0.2,0.2-0.3,0.3c-0.1,0.1-0.2,0.2-0.3,0.3c-0.1,0.1-0.2,0.2-0.3,0.3c-0.1,0.1-0.2,0.2-0.3,0.3c-0.3,0.2-0.5,0.4-0.8,0.6
								c-0.1,0-0.1,0.1-0.2,0.1c-0.1,0.1-0.2,0.1-0.3,0.1c-0.1,0.1-0.4,0.1-0.6,0.2h-0.1h0l-0.1,0h-0.1c-0.1,0-0.2,0-0.3,0
								c-0.2,0-0.5,0-0.7-0.1c-0.1,0-0.2-0.1-0.4-0.1c-0.1,0-0.2-0.1-0.3-0.2c-0.2-0.2-0.4-0.3-0.6-0.5c-0.2-0.2-0.3-0.4-0.4-0.6
								c-0.1-0.2-0.2-0.4-0.3-0.6c-0.1-0.2-0.1-0.4-0.2-0.5C71.5,43.3,71.5,43.1,71.4,43"/>
							<path style="fill:#3B3B48;" d="M78.6,25.5c-0.7,0-1.3-0.2-1.8-0.7c-0.5-0.5-0.7-1.1-0.7-1.8c0-0.7,0.2-1.3,0.7-1.8
								c0.5-0.5,1.1-0.7,1.8-0.7c0.7,0,1.3,0.2,1.7,0.7c0.5,0.5,0.7,1.1,0.7,1.8c0,0.7-0.2,1.3-0.7,1.8C79.9,25.3,79.3,25.5,78.6,25.5"/>
							<path  style="fill:#3B3B48;" d="M80.4,42.3c-0.1-0.3-0.2-0.5-0.2-0.8c0-0.3-0.1-0.6-0.1-0.8c0-0.5,0-1.1,0.1-1.6
								c0-0.1,0-0.3,0.1-0.4c0-0.1,0-0.3,0.1-0.4c0-0.1,0.1-0.3,0.1-0.4c0-0.1,0-0.3,0.1-0.4c0.1-0.2,0.1-0.5,0.2-0.7
								c0.1-0.2,0.2-0.5,0.3-0.7c0.4-0.9,0.8-1.8,1.3-2.5c0.1-0.2,0.3-0.4,0.4-0.6c0.1-0.2,0.3-0.4,0.4-0.6c0.1-0.2,0.3-0.4,0.4-0.5
								c0.2-0.2,0.3-0.3,0.5-0.5c0.2-0.2,0.4-0.3,0.6-0.5c0.2-0.1,0.4-0.3,0.6-0.4c0.4-0.3,0.8-0.6,1.3-0.8c0.5-0.2,1-0.4,1.5-0.5h0.1h0
								l0,0h0h0h0c0,0,0.1,0,0.1,0c0,0,0.1,0,0.1,0c0.1,0,0.1,0,0.2,0c0.1,0,0.1,0,0.2,0c0.2,0,0.3,0,0.5,0.1c0.2,0,0.3,0,0.5,0.1
								c0.1,0,0.2,0.1,0.3,0.1c0.1,0,0.1,0,0.2,0.1c0.1,0,0.2,0.1,0.3,0.1c0.1,0,0.1,0.1,0.2,0.1c0.1,0.1,0.3,0.2,0.4,0.3
								c0.1,0.1,0.3,0.2,0.4,0.4c0.1,0.1,0.2,0.3,0.3,0.4c0.1,0.1,0.2,0.3,0.3,0.5c0.1,0.2,0.1,0.3,0.2,0.5c0.1,0.2,0.1,0.3,0.2,0.5
								c0.1,0.3,0.2,0.6,0.2,0.9c0,0.3,0.1,0.6,0.1,0.9c0,0.6-0.2,1.2-0.4,1.8c-0.2,0.6-0.5,1.2-1,1.7c-0.2,0.2-0.5,0.5-0.8,0.7
								c-0.1,0.1-0.3,0.2-0.4,0.3c-0.1,0.1-0.2,0.1-0.3,0.1c0,0,0,0-0.1,0c0,0,0,0-0.1,0L90,39h0l0,0c-0.5,0.2-1,0.2-1.5-0.1
								c-0.5-0.2-0.8-0.6-1-1.1c-0.1-0.5-0.1-0.9,0-1.4c0.2-0.5,0.5-0.8,0.9-1h0l0,0l0,0c0,0,0.1-0.1,0.1-0.1l0.2-0.2
								c0.1-0.2,0.2-0.3,0.3-0.5c0.1-0.2,0.2-0.5,0.2-0.7c0.1-0.2,0.1-0.5,0.1-0.7c0-0.2,0-0.4-0.1-0.6c-0.1-0.2-0.1-0.3-0.3-0.5
								c0,0-0.1-0.1-0.1-0.1c0,0-0.1-0.1-0.1-0.1c-0.1,0-0.1-0.1-0.2-0.1c0,0-0.1,0-0.1,0h0h0l0,0h-0.1c-0.3-0.1-0.7-0.1-1-0.1
								c-0.1,0-0.2,0-0.3,0.1c-0.1,0-0.2,0-0.3,0.1c-0.1,0-0.2,0.1-0.3,0.1c-0.1,0-0.2,0.1-0.3,0.1c-0.1,0-0.1,0.1-0.2,0.1
								c-0.1,0-0.2,0.1-0.3,0.2c-0.1,0.1-0.1,0.1-0.2,0.2c-0.1,0.1-0.1,0.1-0.2,0.2c-0.6,0.5-1,1.2-1.3,1.9c-0.2,0.4-0.3,0.8-0.4,1.1
								c-0.1,0.4-0.2,0.8-0.2,1.2c-0.1,0.4-0.1,0.8-0.1,1.2c0,0.4,0,0.8,0.1,1.1c0.1,0.4,0.1,0.7,0.2,1c0.1,0.3,0.2,0.6,0.4,0.9
								c0.1,0.2,0.1,0.3,0.2,0.4c0.1,0.1,0.1,0.2,0.2,0.3c0.2,0.2,0.3,0.3,0.5,0.4c0.2,0.1,0.4,0.2,0.6,0.3c0.1,0,0.2,0.1,0.4,0.1
								c0.1,0,0.3,0,0.4,0.1h0.2l0,0h0h0.1h0h0.1h0.1h0.5h0.5c0.1,0,0.2,0,0.3,0c0.1,0,0.2,0,0.3,0c0.4-0.1,0.7-0.1,1.1-0.2
								c0.4-0.1,0.7-0.2,1.1-0.4c0.1,0,0.2-0.1,0.3-0.1c0.1,0,0.2-0.1,0.3-0.1c0.1,0,0.2-0.1,0.3-0.1c0.1-0.1,0.2-0.1,0.3-0.2
								c0.2-0.1,0.4-0.2,0.5-0.3c0.2-0.1,0.4-0.2,0.5-0.3c0.4-0.2,0.7-0.4,1-0.7c0.4-0.2,0.7-0.5,1-0.8c0.1-0.1,0.2-0.2,0.4-0.3
								c0.2-0.2,0.3-0.3,0.4-0.4c0.1-0.1,0.2-0.2,0.3-0.2c0.1-0.1,0.2-0.2,0.3-0.3c0.1-0.1,0.1-0.1,0.2-0.2c0.1-0.1,0.2-0.2,0.3-0.2
								l0.2-0.2l0.1-0.1l0.1-0.1h0c0.1-0.1,0.2-0.1,0.3-0.1c0.1,0,0.2,0,0.3,0.1c0.1,0.1,0.1,0.3,0.1,0.5l-0.1,0.1l-0.1,0.1
								c0,0.1-0.1,0.1-0.1,0.2c0,0,0,0.1-0.1,0.1c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.2-0.3,0.3-0.4,0.5
								c-0.1,0.1-0.2,0.2-0.3,0.5c-0.1,0.2-0.3,0.4-0.3,0.5c-0.6,0.7-1.2,1.4-1.8,2c-0.2,0.2-0.3,0.3-0.5,0.5c-0.2,0.2-0.3,0.3-0.5,0.5
								c-0.1,0.1-0.2,0.2-0.3,0.2c-0.1,0.1-0.2,0.2-0.3,0.2c-0.1,0.1-0.2,0.2-0.3,0.2c-0.1,0.1-0.2,0.1-0.3,0.2c0,0-0.1,0.1-0.1,0.1
								c-0.1,0-0.1,0.1-0.1,0.1c-0.1,0-0.1,0.1-0.2,0.1c0,0-0.1,0.1-0.1,0.1c-0.1,0.1-0.2,0.1-0.3,0.2c-0.1,0.1-0.2,0.1-0.3,0.2
								c-0.2,0.1-0.4,0.3-0.6,0.4c-0.2,0.1-0.4,0.2-0.7,0.3c-0.1,0.1-0.2,0.1-0.4,0.1c-0.1,0.1-0.2,0.1-0.4,0.1c-0.1,0-0.3,0.1-0.4,0.1
								c-0.1,0-0.2,0.1-0.4,0.1c-0.1,0-0.3,0.1-0.4,0.1c-0.1,0-0.3,0-0.4,0.1c-0.1,0-0.1,0-0.1,0h-0.1h-0.1h0h0h0l-0.1,0H86
								c-0.3,0-0.6,0-0.9-0.1c-0.3,0-0.6-0.1-0.9-0.2c-0.3-0.1-0.6-0.2-0.9-0.3c-0.3-0.1-0.6-0.3-0.8-0.5c-0.5-0.4-1-0.9-1.3-1.4
								c-0.2-0.3-0.3-0.5-0.4-0.8S80.5,42.6,80.4,42.3"/>
						</svg>

					</div>
				</div>
				
			</section>
			

			<section id="section-contact">

				<a id="href-nav-contact"></a>

				<div class="section-contact_background"></div>

				<h4 class="f-mpl_1">LET'S TALK</h4>

				<h5 class="f-mpl_3">EN QUOI POUVONS-NOUS VOUS ÊTRE UTILE ?</h5>

				<strong class="f-sf_r">Répondez à quelques questions<br>et nous vous proposerons une solution.</strong>
				
				<a class="btn-style delay f-mpl_m" href="HireMe/">
					<span>CONTACT</span>
				</a>
				
			</section>

		</div>

		<footer id="footer-general">
	
	<svg class="logo" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 60 60">
		<title>Agence Me Logo</title>
		<path d="M40 53C40 36.43146 53.43146 23 70 23C86.56854 23 100 36.43146 100 53C100 69.56854 86.56854 83 70 83C53.43146 83 40 69.56854 40 53Z " fill="#3b3b48" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
		<path  d="M75.00888 46.79154C75.34639 46.354389999999995 76.06771 46 76.62 46L81.19 46C81.74228 46 81.91964 46.35687 81.58614 46.79709L72.79386 58.40291C72.46036 58.843129999999995 71.74243 59.18853 71.19032999999999 59.174369999999996L66.55966999999998 59.05564C66.00756999999999 59.04148 65.83360999999998 58.675619999999995 66.17111999999999 58.23847Z " fill="#d4d4d4" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
		<path d="M65.07157 46.79361C65.40759999999999 46.35531 66.12772 46 66.67999999999999 46L71.25 46C71.80228 46 71.97964 46.35687 71.64614 46.79709L62.853860000000005 58.40291C62.520360000000004 58.843129999999995 61.802290000000006 59.199999999999996 61.25000000000001 59.199999999999996L56.56000000000001 59.199999999999996C56.007720000000006 59.199999999999996 55.83240000000001 58.84468999999999 56.16843000000001 58.406389999999995Z " fill="#ffffff" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
		<path d="M75 47C75 46.44772 75.44772 46 76 46L80.69 46C81.24228 46 81.69 46.44772 81.69 47L81.69 55.46C81.69 56.012280000000004 81.36913 56.772240000000004 80.97332 57.1574L75.71669 62.272600000000004C75.32088 62.65776 75.00001 62.52228 75.00001 61.970000000000006Z " fill="#ffffff" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
		<path d="M66 47C66 46.44772 66.44772 46 67 46L71.69 46C72.24228 46 72.69 46.44772 72.69 47L72.69 58.2C72.69 58.752280000000006 72.24228 59.2 71.69 59.2L67 59.2C66.44772 59.2 66 58.752280000000006 66 58.2Z " fill="#f0f0f0" fill-opacity="1" transform="matrix(1,0,0,1,-40,-23)"></path>
	</svg>

	<div class="social">
		<div class="title f-mpl_3">SOCIAL</div>
		<div class="subtitle f-sf_r">Follow us</div>
		<div class="link">
			<a href="https://dribbble.com/AgenceMe">
				<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 17 17">
					<path d="M299.21 6271.18C299.34 6271.18 302.83 6271.26 306.46999999999997 6270.16C306.67999999999995 6270.5599999999995 306.86999999999995 6270.97 307.04999999999995 6271.38C306.94999999999993 6271.400000000001 306.85999999999996 6271.43 306.77 6271.46C302.95 6272.72 301.02 6276.2 301.02 6276.2C299.89 6274.929999999999 299.21 6273.25 299.21 6271.41C299.21 6271.33 299.21 6271.26 299.21 6271.18ZM301.77 6276.94C301.87 6277.0199999999995 301.93 6277.07 301.93 6277.07C301.93 6277.07 303.29 6274.07 307.48 6272.58C307.5 6272.58 307.51 6272.57 307.53000000000003 6272.57C308.52000000000004 6275.19 308.93 6277.389999999999 309.04 6278.0199999999995C308.19 6278.379999999999 307.26000000000005 6278.589999999999 306.28000000000003 6278.589999999999C304.57000000000005 6278.589999999999 303.00000000000006 6277.969999999999 301.77000000000004 6276.94ZM305.89 6269.05C302.49 6269.97 299.55 6269.93 299.36 6269.93C299.82 6267.700000000001 301.29 6265.860000000001 303.26 6264.91C303.36 6265.04 304.65999999999997 6266.84 305.89 6269.05ZM307.25 6268.62C306.05 6266.36 304.72 6264.57 304.61 6264.43C305.15000000000003 6264.3 305.7 6264.2300000000005 306.28000000000003 6264.2300000000005C308.07000000000005 6264.2300000000005 309.70000000000005 6264.910000000001 310.95000000000005 6266.02C310.93000000000006 6266.05 309.9200000000001 6267.6 307.25000000000006 6268.620000000001ZM308.42 6271.1C308.37 6270.9800000000005 308.32 6270.85 308.27000000000004 6270.7300000000005C308.12000000000006 6270.38 307.96000000000004 6270.030000000001 307.8 6269.6900000000005C310.59000000000003 6268.530000000001 311.73 6266.870000000001 311.74 6266.85C312.73 6268.070000000001 313.33 6269.63 313.35 6271.34C313.25 6271.31 310.85 6270.79 308.42 6271.1ZM308.85 6272.23C311.14000000000004 6271.86 313.11 6272.5 313.26000000000005 6272.549999999999C312.95000000000005 6274.549999999999 311.82000000000005 6276.2699999999995 310.2300000000001 6277.36C310.1600000000001 6276.929999999999 309.7800000000001 6274.82 308.8500000000001 6272.23ZM313.91 6268.13C313.70000000000005 6267.64 313.44 6267.16 313.14000000000004 6266.71C312.85 6266.26 312.51000000000005 6265.84 312.13000000000005 6265.46C311.76000000000005 6265.08 311.3500000000001 6264.74 310.91 6264.44C310.47 6264.129999999999 309.99 6263.87 309.5 6263.66C309 6263.45 308.48 6263.28 307.95 6263.17C307.4 6263.06 306.84 6263 306.28 6263C305.71999999999997 6263 305.15999999999997 6263.06 304.60999999999996 6263.17C304.08 6263.28 303.55999999999995 6263.45 303.05999999999995 6263.66C302.56999999999994 6263.87 302.0899999999999 6264.13 301.6499999999999 6264.44C301.2099999999999 6264.74 300.7999999999999 6265.08 300.4199999999999 6265.46C300.0499999999999 6265.84 299.7099999999999 6266.26 299.4099999999999 6266.71C299.1199999999999 6267.16 298.8599999999999 6267.64 298.6499999999999 6268.13C298.43999999999994 6268.64 298.2799999999999 6269.18 298.1699999999999 6269.72C298.0599999999999 6270.27 297.9999999999999 6270.84 297.9999999999999 6271.41C297.9999999999999 6271.98 298.0599999999999 6272.55 298.1699999999999 6273.099999999999C298.2799999999999 6273.639999999999 298.4399999999999 6274.169999999999 298.6499999999999 6274.679999999999C298.8599999999999 6275.179999999999 299.11999999999995 6275.659999999999 299.4099999999999 6276.11C299.7099999999999 6276.549999999999 300.0499999999999 6276.969999999999 300.4199999999999 6277.349999999999C300.7999999999999 6277.73 301.2099999999999 6278.079999999999 301.6499999999999 6278.379999999999C302.0899999999999 6278.679999999999 302.56999999999994 6278.94 303.05999999999995 6279.15C303.55999999999995 6279.37 304.0799999999999 6279.53 304.60999999999996 6279.639999999999C305.15999999999997 6279.759999999999 305.71999999999997 6279.8099999999995 306.28 6279.8099999999995C306.84 6279.8099999999995 307.4 6279.759999999999 307.95 6279.639999999999C308.47999999999996 6279.53 309 6279.369999999999 309.5 6279.15C309.99 6278.94 310.47 6278.679999999999 310.91 6278.379999999999C311.35 6278.079999999999 311.76000000000005 6277.73 312.13000000000005 6277.349999999999C312.51000000000005 6276.969999999999 312.8500000000001 6276.549999999999 313.14000000000004 6276.11C313.44000000000005 6275.66 313.70000000000005 6275.179999999999 313.91 6274.679999999999C314.12 6274.169999999999 314.28000000000003 6273.639999999999 314.39000000000004 6273.099999999999C314.50000000000006 6272.549999999999 314.56000000000006 6271.98 314.56000000000006 6271.41C314.56000000000006 6270.84 314.50000000000006 6270.2699999999995 314.39000000000004 6269.72C314.28000000000003 6269.18 314.12000000000006 6268.64 313.91 6268.13Z " fill-opacity="1" transform="matrix(1,0,0,1,-298,-6263)"></path>
				</svg>
			</a>
			<a href="https://www.behance.net/barthelemychalvet">
				<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 18 11">
					<path d="M358.58 6270.12C358.9 6270.59 359.10999999999996 6271.13 359.21 6271.75C359.26 6272.12 359.28 6272.64 359.28 6273.32L353.52 6273.32C353.56 6274.12 353.83 6274.67 354.34999999999997 6274.99C354.65999999999997 6275.19 355.03999999999996 6275.29 355.48999999999995 6275.29C355.96 6275.29 356.34 6275.17 356.62999999999994 6274.93C356.78999999999996 6274.8 356.93999999999994 6274.610000000001 357.05999999999995 6274.38L359.16999999999996 6274.38C359.10999999999996 6274.85 358.84999999999997 6275.33 358.4 6275.81C357.69 6276.580000000001 356.7 6276.97 355.42999999999995 6276.97C354.37999999999994 6276.97 353.44999999999993 6276.64 352.65 6275.990000000001C351.84999999999997 6275.340000000001 351.45 6274.290000000001 351.45 6272.830000000001C351.45 6271.460000000001 351.81 6270.400000000001 352.53 6269.670000000001C353.26 6268.940000000001 354.2 6268.580000000001 355.35999999999996 6268.580000000001C356.03999999999996 6268.580000000001 356.65999999999997 6268.700000000001 357.21 6268.950000000001C357.76 6269.1900000000005 358.21999999999997 6269.580000000001 358.58 6270.120000000001ZM344.13 6271.99L346.76 6271.99C347.21 6271.99 347.57 6272.05 347.82 6272.17C348.28 6272.38 348.5 6272.76 348.5 6273.32C348.5 6273.969999999999 348.27 6274.42 347.8 6274.65C347.55 6274.78 347.18 6274.839999999999 346.72 6274.839999999999L344.13000000000005 6274.839999999999ZM344.13 6267.86L346.45 6267.86C346.96 6267.86 347.38 6267.91 347.71999999999997 6268.0199999999995C348.09999999999997 6268.179999999999 348.28999999999996 6268.509999999999 348.28999999999996 6269.009999999999C348.28999999999996 6269.459999999999 348.14 6269.7699999999995 347.84999999999997 6269.949999999999C347.55999999999995 6270.129999999999 347.18999999999994 6270.219999999999 346.71999999999997 6270.219999999999L344.13 6270.219999999999ZM353.04 6267.83L353.04 6266.5L357.62 6266.5L357.62 6267.83ZM353.57 6271.96L357.13 6271.96C357.09 6271.41 356.90999999999997 6270.99 356.58 6270.71C356.25 6270.42 355.84 6270.28 355.35999999999996 6270.28C354.83 6270.28 354.41999999999996 6270.429999999999 354.11999999999995 6270.73C353.8299999999999 6271.04 353.6499999999999 6271.44 353.56999999999994 6271.959999999999ZM349.93 6267.14C349.38 6266.400000000001 348.46 6266.02 347.16 6266L342 6266L342 6276.7L346.81 6276.7C347.35 6276.7 347.86 6276.65 348.32 6276.55C348.78 6276.45 349.19 6276.28 349.53 6276.02C349.83 6275.790000000001 350.08 6275.51 350.28 6275.17C350.59999999999997 6274.67 350.76 6274.1 350.76 6273.47C350.76 6272.85 350.62 6272.33 350.34 6271.900000000001C350.06 6271.47 349.65 6271.160000000001 349.10999999999996 6270.960000000001C349.46999999999997 6270.770000000001 349.73999999999995 6270.570000000001 349.91999999999996 6270.350000000001C350.24999999999994 6269.950000000002 350.41999999999996 6269.420000000001 350.41999999999996 6268.770000000001C350.41999999999996 6268.140000000001 350.24999999999994 6267.590000000001 349.92999999999995 6267.140000000001Z " fill-opacity="1" transform="matrix(1,0,0,1,-342,-6266)"></path>
				</svg>
			</a>
			<a href="https://www.facebook.com/agenceME/?ref=ts&fref=ts">
				<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs"  viewBox="0 0 16 16">
					<path d="M435.42 6280L427.87 6280C427.39 6280 427 6279.6 427 6279.12L427 6264.88C427 6264.400000000001 427.39 6264 427.87 6264L441.89 6264C442.37 6264 442.76 6264.4 442.76 6264.88L442.76 6279.12C442.76 6279.599999999999 442.37 6280 441.89 6280L437.87 6280L437.87 6273.8L439.92 6273.8L440.23 6271.39L437.87 6271.39L437.87 6269.85C437.87 6269.150000000001 438.06 6268.67 439.05 6268.67L440.31 6268.67L440.31 6266.51C440.09 6266.4800000000005 439.34 6266.42 438.47 6266.42C436.66 6266.42 435.42 6267.54 435.42 6269.61L435.42 6271.389999999999L433.36 6271.389999999999L433.36 6273.799999999999L435.42 6273.799999999999Z " fill-opacity="1" transform="matrix(1,0,0,1,-427,-6264)"></path>
				</svg>
			</a>
			<a href="https://twitter.com/AgenceMe">
				<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 18 15">
					<path d="M487.28 6266.73C486.64 6267.0199999999995 485.96 6267.219999999999 485.23999999999995 6267.3099999999995C485.96999999999997 6266.86 486.53999999999996 6266.129999999999 486.79999999999995 6265.2699999999995C486.11999999999995 6265.69 485.35999999999996 6265.999999999999 484.54999999999995 6266.16C483.9 6265.45 482.97999999999996 6265 481.96 6265C480.01 6265 478.41999999999996 6266.65 478.41999999999996 6268.69C478.41999999999996 6268.98 478.44999999999993 6269.259999999999 478.50999999999993 6269.53C475.55999999999995 6269.38 472.94999999999993 6267.91 471.19999999999993 6265.67C470.8999999999999 6266.22 470.7199999999999 6266.86 470.7199999999999 6267.53C470.7199999999999 6268.8099999999995 471.3499999999999 6269.94 472.2999999999999 6270.599999999999C471.7199999999999 6270.589999999999 471.1699999999999 6270.419999999999 470.6899999999999 6270.139999999999L470.6899999999999 6270.19C470.6899999999999 6271.98 471.9199999999999 6273.469999999999 473.5399999999999 6273.8099999999995C473.2399999999999 6273.889999999999 472.9299999999999 6273.94 472.5999999999999 6273.94C472.3799999999999 6273.94 472.1499999999999 6273.919999999999 471.9399999999999 6273.87C472.3899999999999 6275.34 473.6999999999999 6276.41 475.2499999999999 6276.43C474.0399999999999 6277.42 472.5099999999999 6278.01 470.8499999999999 6278.01C470.5599999999999 6278.01 470.2799999999999 6278 469.9999999999999 6277.96C471.5699999999999 6279.01 473.4299999999999 6279.62 475.4299999999999 6279.62C481.9499999999999 6279.62 485.51999999999987 6274 485.51999999999987 6269.12C485.51999999999987 6268.96 485.51999999999987 6268.8 485.5099999999999 6268.64C486.1999999999999 6268.12 486.7999999999999 6267.47 487.27999999999986 6266.7300000000005 " fill-opacity="1" transform="matrix(1,0,0,1,-470,-6265)"></path>
				</svg>
			</a>
			<a href="http://agencemeinspi.tumblr.com">
				<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 9 17">
					<path d="M523.21 6276.88C522.9200000000001 6277.02 522.36 6277.14 521.95 6277.150000000001C520.7 6277.1900000000005 520.46 6276.250000000001 520.45 6275.570000000001L520.45 6270.55L523.58 6270.55L523.58 6268.110000000001L520.46 6268.110000000001L520.46 6264.000000000001C520.46 6264.000000000001 518.21 6264.000000000001 518.1800000000001 6264.000000000001C518.1400000000001 6264.000000000001 518.08 6264.030000000001 518.07 6264.120000000001C517.9300000000001 6265.380000000001 517.36 6267.580000000001 515 6268.460000000001L515 6270.550000000001L516.58 6270.550000000001L516.58 6275.810000000001C516.58 6277.620000000002 517.86 6280.180000000001 521.26 6280.120000000002C522.4 6280.100000000001 523.67 6279.600000000001 523.96 6279.170000000002L523.21 6276.880000000002 " fill-opacity="1" transform="matrix(1,0,0,1,-515,-6264)"></path>
				</svg>
			</a>
		</div>
	</div>

	<div class="hire">
		<div class="title f-mpl_3">HIRE</div>
		<div class="subtitle f-sf_r">Let us know how we can help you.</div>
		<a class="f-sf_r" href="http://www.agence-me.com/HireMe/">
			<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 12.813997466514593 12.772225441594117">
				<path d="M1311.25 48C1308.35 48 1306 50.35 1306 53.25C1306 54.2 1306.25 55.09 1306.7 55.86L1306 58.45L1308.57 57.760000000000005C1309.36 58.230000000000004 1310.27 58.49 1311.25 58.49C1314.14 58.49 1316.49 56.14 1316.49 53.25C1316.49 50.35 1314.14 48 1311.25 48Z " fill-opacity="0" fill="#ffffff" stroke-dasharray="0" stroke-linejoin="miter" stroke-linecap="butt" stroke-opacity="1" stroke-miterlimit="50" stroke-width="1.5" transform="matrix(1,0,0,1,-1305.0930012667427,-47.11388727920294)"></path>
			</svg>
			HIRE ME
			<svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17">
			    <path stroke-linejoin="miter" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 10.81 8.5 L 8.5 8.5 C 7.23 8.5 6.19 9.53 6.19 10.81"></path>
			    <path stroke-linejoin="miter" stroke-linecap="butt" stroke-width="1" fill="none" fill-rule="evenodd" d="M 1 8.5 C 1 12.64 4.36 16 8.5 16 C 12.64 16 16 12.64 16 8.5 C 16 4.36 12.64 1 8.5 1 C 4.36 1 1 4.36 1 8.5 L 1 8.5 Z M 1 8.5"></path>
			    <path stroke-linejoin="round" stroke-linecap="round" stroke-width="1" fill="none" fill-rule="evenodd" d="M 8.5 6.19 L 10.81 8.5 L 8.5 10.81"></path>
			</svg>
		</a>

	</div>

	<div class="market">
		<div class="title">
			<div class="new f-mpl_3">NEW</div>
			<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" viewBox="0 0 15 18">
				<path d="M1019.4 6225.61C1019.4 6225.87 1019.28 6226 1019.03 6226L1018.53 6226C1018.28 6226 1018.15 6225.87 1018.15 6225.61L1018.15 6213.759999999999C1018.15 6213.369999999999 1017.87 6213.299999999999 1017.6999999999999 6213.629999999999L1013.4399999999999 6221.369999999999C1013.3399999999999 6221.549999999999 1013.1899999999999 6221.549999999999 1013.0899999999999 6221.369999999999L1005.9999999999999 6208.459999999999C1005.8499999999999 6208.209999999999 1005.9799999999999 6207.999999999999 1006.2799999999999 6207.999999999999L1006.8799999999999 6207.999999999999C1007.0799999999999 6207.999999999999 1007.2299999999999 6208.079999999999 1007.3299999999999 6208.259999999999L1013.02 6218.669999999999C1013.17 6218.929999999999 1013.37 6218.929999999999 1013.52 6218.669999999999L1019.1 6208.539999999999C1019.23 6208.329999999999 1019.4 6208.359999999999 1019.4 6208.619999999999ZM1011.74 6222.35C1011.54 6222.35 1011.39 6222.27 1011.29 6222.09L1006.6999999999999 6213.63C1006.53 6213.3 1006.2499999999999 6213.37 1006.2499999999999 6213.76L1006.2499999999999 6225.610000000001C1006.2499999999999 6225.870000000001 1006.1299999999999 6226.000000000001 1005.8799999999999 6226.000000000001L1005.3799999999999 6226.000000000001C1005.1299999999999 6226.000000000001 1004.9999999999999 6225.870000000001 1004.9999999999999 6225.610000000001L1004.9999999999999 6208.620000000001C1004.9999999999999 6208.360000000001 1005.1799999999998 6208.330000000001 1005.2999999999998 6208.540000000001L1012.6399999999999 6221.890000000001C1012.7899999999998 6222.140000000001 1012.6599999999999 6222.350000000001 1012.3599999999999 6222.350000000001ZM1017.52 6225.61C1017.52 6225.87 1017.4 6226 1017.15 6226L1016.65 6226C1016.4 6226 1016.27 6225.87 1016.27 6225.61L1016.27 6217.7699999999995C1016.27 6217.589999999999 1016.3 6217.459999999999 1016.4 6217.28L1017.22 6215.82C1017.35 6215.59 1017.52 6215.639999999999 1017.52 6215.889999999999ZM1008.13 6225.61C1008.13 6225.87 1008.01 6226 1007.76 6226L1007.25 6226C1007 6226 1006.88 6225.87 1006.88 6225.61L1006.88 6215.889999999999C1006.88 6215.639999999999 1007.05 6215.589999999999 1007.18 6215.82L1008.01 6217.28C1008.11 6217.46 1008.13 6217.59 1008.13 6217.7699999999995ZM1012.71 6216.31C1012.61 6216.490000000001 1012.61 6216.64 1012.71 6216.820000000001L1013.09 6217.460000000001C1013.19 6217.640000000001 1013.34 6217.640000000001 1013.44 6217.460000000001L1018.4000000000001 6208.460000000001C1018.5500000000001 6208.210000000001 1018.4300000000001 6208.000000000001 1018.1200000000001 6208.000000000001L1017.5200000000001 6208.000000000001C1017.32 6208.000000000001 1017.1700000000001 6208.080000000001 1017.07 6208.260000000001Z " fill="#333333" fill-opacity="1" transform="matrix(1,0,0,1,-1005,-6208)"></path>
			</svg>
		</div>
		<div class="subtitle f-sf_r">Market Place for Premium Design Ressources</div>
		<a href="https://www.market-me.fr" class="f-sf_r">DISCOVER</a>
	</div>


	<div class="car f-sf_r">
		© 2016 AgenceMe,  13 rue de le nostre, 76000 Rouen
	</div>













</footer>

		<!-- SCRIPT -->
	    
	    <script type="text/javascript" src="js/index.js"></script>

	    <!-- END SCRIPT -->

	    <!-- Start of Async Drift Code -->
		<script>
		!function() {
		  var t;
		  if (t = window.driftt = window.drift = window.driftt || [], !t.init) return t.invoked ? void (window.console && console.error && console.error("Drift snippet included twice.")) : (t.invoked = !0,
		  t.methods = [ "identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on" ],
		  t.factory = function(e) {
		    return function() {
		      var n;
		      return n = Array.prototype.slice.call(arguments), n.unshift(e), t.push(n), t;
		    };
		  }, t.methods.forEach(function(e) {
		    t[e] = t.factory(e);
		  }), t.load = function(t) {
		    var e, n, o, i;
		    e = 3e5, i = Math.ceil(new Date() / e) * e, o = document.createElement("script"),
		    o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + i + "/" + t + ".js",
		    n = document.getElementsByTagName("script")[0], n.parentNode.insertBefore(o, n);
		  });
		}();
		drift.SNIPPET_VERSION = '0.3.1';
		drift.load('2ke53x392p7x');
		</script>
		<!-- End of Async Drift Code -->
	    
	</body>
	
</html>